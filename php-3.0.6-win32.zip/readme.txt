Welcome to PHP 3 for Windows!


NOTICE!!!  All modules have changed!  They are now prefixed with php3_.  You will need to change
you php3.ini file and/or any scripts loading extensions with the dl() function!!!  (or
you could always remove the php3_ prefix).  This was done to help prevent confusion between
php modules, and their supporting dll's.

NOTE!!!!  You need to copy the php3.ini-dist file into your windows directory and rename
it to php3.ini.  Be sure to edit this file to reflect the settings you need.


If you have used the setup program, and have IIS or PWS, you are almost
ready to go.  You must first decide which directories in your web server
will contain php scripts, and make those directories executable. You will need to
manualy edit configurations for other web servers.  Otherwise, you can
follow the instructions below for installation.

Please be sure to see the ChangeLog, Changes, FAQ.html and FunctionList.txt
files for more information about this distribution.  Updated docs are always
located at http://www.php.net/

----------------------------------------------------------------------

About the Registry
Microsoft servers require that some settings be made in the registry.

An INF file (php_iis_reg.inf) has been included that will automaticaly add registry settings for
IIS 3 and PWS.

registry entries for PWS & IIS:
HKEY_LOCAL_MACHINE:System\CurrentControlSet\Services\W3Svc\Parameters\Script Map
.php3 "c:\php3\php.exe %s %s"

As more server specific information is gathered, more registry entries may
be added.

NOTE: I have not been able to get php to work correctly with PWS 4

----------------------------------------------------------------------
INSTALLATION

Make a directory, such as c:\php3, and place all the rest of the dlls there.

If you are not using Apache NT server, you can set an environment
variable in your autoexec.bat file, add this line:

SET PHPRC=\windows\php3.ini

and place your php3.ini file in whatever directory you specify.
Otherwise, be sure to place php3.ini in your os directory 
(typicaly c:\windows or c:\winnt).

msql1.dll, calendar.dll and msql2.dll must be located in the
same directory as php3.exe, or you must specify where these files
are located either in your php3.ini file, or in the php3 script.

You can load modules at startup via the ini file by placing a line like:
extension=dbase.dll
in your ini file,
OR
To use a loadable module in your script you must have the following
command:

dl("dbase.dll");

For further instructions, html manual, reporting bugs, etc., 
see www.php.net

------------------
PHP and Apache CGI
PHP will look under your os directory (\windows or \winnt) for php3.ini
See the PHP2 docs for more information on redirection under apache

-------------------------
PHP and Microsoft Servers
You need to edit the registry.  DO THIS AT YOUR OWN RISK!  We will not
be held responsible for damaged registry files.  Back up your registry!
Future releases will have an installation program.
To edit your registry, go to the start button and select "run".  Type in
regedit and press enter.
Go to: 
HKEY_LOCAL_MACHINE:System:CurrentControlSet:Services:W3Svc:Parameters:ScriptMap
Go to the edit menu and select new->string value
type in the EXTENSION you wish to use for your php scripts '.php3'
Double click on the new key and enter the path to php.exe in the
value data field 'c:\php3\php.exe'.
Now, you must make the directory containing your php scripts both browsable
and executable.  See your server documentation on how to do this.

Notes on IIS4
--------------------
Start Internet Service Manager
Right click on the website you are installing php in
Select properties
Click on the TAB "Home Directory"
Select 'Script' under permisions
Click on button 'Configuration'
Click on button 'Add'
Executable should be c:\php3\php.exe %s %s (Yes, TWO %s's acording to M$ docs)
Extension .php (or whatever you use)
Check 'Script Engine'
Click on OK
Click on OK again.
Stop then Start the web server.
PHP should now work.  If it doesn't verify the 'everyone' has full access to the 
directory c:\php3 and everything within it.

Try running a simple script such as <? phpinfo(); ?>

----------------
PHP ISAPI Module
This module IS NOT THREAD SAFE yet, and is not publicly distributed at
this time.  You can get the isapi module from the cvs tree.  
Do not use in any production environment.  Setting up this module
for MSPWS or IIS is the same as setting up the cgi module in the registry.
See the php email list archives for details.


---------------------------------------------------------------------
External Modules:

Not all these modules will be supported inthe future.  Some libraries
required to build some of these modules are not thread safe and will
not be supported until they are (msql and gd are two such libraries
that are not thread safe)

snmp.dll	SNMP Get and Walk functions (NT ONLY!)
msql2.dll	mSQL 2 client
dbase.dll	DBASE functions
ldap.dll	LDAP functions
gd.dll		GD Library functions for gif manipulation
dbm.dll		GDBM emulation via Berkely DB2 library
filepro.dll	READ ONLY access to filepro databases
calendar.dll	Calendar conversion functions
mysql.dll       MySQL functions (currently compiled into php.exe)

For a full list of functions available, see FUNCTION_LIST.txt.  This file
is not a manual, but may be handy to have until we finish the new documentation.

CONVERT.EXE

This is the php/fi 2 to php 3 converter.  See the php3 website for more
information on its limitations.  Generaly, there will still be converting
work to be done after using this program on a script, but this will get
a lot of dirty work done.

SOCKET
You can download a port of the socket program from the php site which can be
used to see the debugger output from php.
