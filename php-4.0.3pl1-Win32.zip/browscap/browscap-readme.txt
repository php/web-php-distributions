
In concordance with the End User License Authorization 
(EULA) for Microsoft Internet Information Server, 
Microsoft has forbidden me to redistribute 
browscap.ini, a file included with IIS.

So, I'm now distributing browscap.txt
...which is not a file distributed with IIS.

All the content in browscap.txt 
is Copyright Juan T. Llibre 
j.llibre@codetel.net.do

Downloading browscap.txt gives you authorization
to use the file in any Windows server you own, 
or the company you may work for owns.

You cannot redistribute browscap.txt.

On the other hand, it will always be available, free of charge, 
at http://asptracker.com/browscap.zip .

To use it, extract browscap.txt and browsupd.bat 
to \system\32\inetsrv, and run browsupd.bat.

This will replace the copyrighted contents
of browscap.ini with user-modified content.

Please back up your current browscap.ini before testing ours.

Please note that this browscap configuration file has built-in protection
against indiscriminate Offline Retrievers, i.e., as soon as I detect an
Offline browser, I identify it as "ACrawler", so that with one call to :

if bc.browser="ACrawler" then
Response.redirect "http://www.microsoft.com/"
End if

I can prevent ANY Offline Browser from hitting the site with many consecutive requests. 

If you don't wish for this capability to be operational, just review 
the "Crawler" section of the file, and replace the generic "ACrawler" 
browser ID with the Crawlers' browser name.

I removed all beta ID strings from the basic browscap.ini file, 
except for the IE5 Beta and a couple of Netscape betas.

They are included in browscap-beta.txt.

If you wish to detect those beta versions, add the strings to browscap.ini.

regards,


Juan T. Llibre
