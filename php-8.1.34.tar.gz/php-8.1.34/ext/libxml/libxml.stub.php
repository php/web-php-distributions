<?php

/** @generate-class-entries */

class LibXMLError
{
    public int $level;
    public int $code;
    public int $column;
    public string $message;
    public string $file;
    public int $line;
}

/** @param resource $context */
function libxml_set_streams_context($context): void {}

function libxml_use_internal_errors(?bool $use_errors = null): bool {}

function libxml_get_last_error(): LibXMLError|false {}

/** @return array<int, LibXMLError> */
function libxml_get_errors(): array {}

function libxml_clear_errors(): void {}

/** @deprecated */
function libxml_disable_entity_loader(bool $disable = true): bool {}

function libxml_set_external_entity_loader(?callable $resolver_function): bool {}
