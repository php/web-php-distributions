<?php
$s = new Mono('System.Collections.Stack');
$m = mono_method_find($s, 'Push:o');
$m->call('Mono');

$Console = new Mono('System.Console');
$Console->WriteLine($s->Pop());
?>
