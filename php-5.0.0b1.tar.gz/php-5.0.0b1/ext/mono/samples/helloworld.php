<?php
$Console = new Mono('System.Console');
$Console->WriteLine("Hello World");
?>
