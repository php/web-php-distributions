/*
  +----------------------------------------------------------------------+
  | PHP-Mono v0.2                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 2003 Sterling Hughes <sterling@php.net>                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 2.02 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available at through the world-wide-web at                           |
  | http://www.php.net/license/2_02.txt.                                 |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author: Sterling Hughes <sterling@php.net>                           |
  +----------------------------------------------------------------------+
*/

/* $Id: php_mono.c,v 1.7 2003/06/05 16:52:29 sterling Exp $ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"

#if HAVE_MONO

#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_mono.h"
#include <string.h>
#include <mono/metadata/tabledefs.h>
#include "ext/standard/php_smart_str.h"

ZEND_DECLARE_MODULE_GLOBALS(mono);

MonoDomain *domain;
zend_class_entry *mono_class_entry;
zend_class_entry *mono_method_class_entry;
zend_function *mono_constructor;
zend_function *mono_method_call;

static zend_object_value object_new(zend_class_entry * TSRMLS_DC);

static inline php_mono_object *
php_mono_fetch_object(zval *object TSRMLS_DC) 
{
	php_mono_object *pm;

	pm = (php_mono_object *) zend_object_store_get_object(object TSRMLS_CC);
	return pm;
}

static inline MonoClassField *
fetch_field_desc(MonoClass *class, const char *name TSRMLS_DC)
{
	MonoClassField *field;

	field = mono_class_get_field_from_name(class, name);
	if (field == NULL) {
		php_error(E_WARNING, "Couldn't access class field description");
		return NULL;
	}

	return field;
}

#define data_offset(p) ((p) + sizeof(MonoObject))
#define get_value(p, type) (*(type *) data_offset(p))

static void
create_php_object(MonoTypeEnum type, zval **return_value, MonoObject *object TSRMLS_DC)
{
	switch (type) {
	case MONO_TYPE_VOID:
		ZVAL_NULL(*return_value);
		break;
	case MONO_TYPE_BOOLEAN:
		ZVAL_BOOL(*return_value, get_value(object, guint8));
		break;
	case MONO_TYPE_U1:
	case MONO_TYPE_I1:
		ZVAL_LONG(*return_value, get_value(object, guint8));
		break;
	case MONO_TYPE_I2:
	case MONO_TYPE_U2:
	case MONO_TYPE_CHAR:
		ZVAL_LONG(*return_value, get_value(object, guint16));
		break;
	case MONO_TYPE_I4:
	case MONO_TYPE_U4:
		ZVAL_LONG(*return_value, get_value(object, gint32));
		break;
	case MONO_TYPE_I8:
	case MONO_TYPE_U8:
		ZVAL_LONG(*return_value, get_value(object, gint64));
		break;
	case MONO_TYPE_R4:
		ZVAL_DOUBLE(*return_value, get_value(object, float));
		break;
	case MONO_TYPE_R8:
		ZVAL_DOUBLE(*return_value, get_value(object, double));
		break;
	case MONO_TYPE_VALUETYPE:
		ZVAL_LONG(*return_value, (long) object);
		break;
	case MONO_TYPE_STRING:
		ZVAL_STRINGL(*return_value, mono_string_to_utf8((MonoString *) object), 
					 mono_string_length((MonoString *) object), 1);
		break;
	case MONO_TYPE_ARRAY: 
	case MONO_TYPE_OBJECT: {
		php_mono_object *pm;

		Z_TYPE_PP(return_value) = IS_OBJECT;
		(*return_value)->value.obj = object_new(mono_class_entry TSRMLS_CC);

		pm = zend_object_store_get_object(*return_value TSRMLS_CC);
		pm->mobject = object;
		pm->mclass = object->vtable->klass;
		pm->mimage = object->vtable->klass->image;
		break;
	} 
	default:
		php_error(E_WARNING, "Unsupported type");
		break;
	}
}

static void
create_mono_object(MonoClass *class, MonoObject **rv, zval *value TSRMLS_DC)
{
	MonoString *s;

	switch (Z_TYPE_P(value)) {
	case IS_LONG:
	case IS_BOOL:
		*rv = mono_object_new(domain, class);
		if (class->valuetype) {
			memcpy(*rv, &Z_LVAL_P(value), sizeof(long));
		} else {
			memcpy(data_offset(*rv), &Z_LVAL_P(value), sizeof(long));
		}
		break;
	case IS_DOUBLE:
		*rv = mono_object_new(domain, class);
		memcpy(data_offset(*rv), &Z_DVAL_P(value), sizeof(double));
		break;
	case IS_STRING: 
		s = mono_string_new(domain, Z_STRVAL_P(value));
		*rv = (MonoObject *) s;
		break;
	case IS_OBJECT: {
		php_mono_object *pm;

		if (Z_OBJCE_P(value) != mono_class_entry) {
			php_error(E_WARNING, "Currently non Mono objects are not supported");
			return;
		} 

		zval_add_ref(&value);
		pm = php_mono_fetch_object(value TSRMLS_CC);
		*rv = pm->mobject;
		break;
	}
	default:
		break;
	}
}

static zval *
property_read(zval *object, zval *member TSRMLS_DC)
{
	zval            *rv;
	php_mono_object *pm;
	MonoClassField  *field;
	MonoObject      *value;

	MAKE_STD_ZVAL(rv);
	ZVAL_NULL(rv);

	if (Z_TYPE_P(member) != IS_STRING) {
		php_error(E_WARNING, "Cannot access non-string properties on a mono object");
		return rv;
	}
	
	pm = php_mono_fetch_object(object TSRMLS_CC);
	field = fetch_field_desc(pm->mclass, Z_STRVAL_P(member) TSRMLS_CC);
	if (field == NULL) {
		return rv;
	}

	if (field->type->attrs & FIELD_ATTRIBUTE_STATIC) {
		mono_field_static_get_value(pm->mobject->vtable, field, &value);
	} else {
		mono_field_get_value(pm->mobject, field, &value);
	}

	create_php_object(field->type->type, &rv, value TSRMLS_CC);
	
	return rv;
}

static void
property_write(zval *object, zval *member, zval *zvalue TSRMLS_DC)
{
	php_mono_object *pm;
	MonoClassField  *field;
	MonoObject      *value;

	if (Z_TYPE_P(member) != IS_STRING) {
		php_error(E_WARNING, "Cannot access non-string properties on a mono object");
		return;
	}

	pm = php_mono_fetch_object(object TSRMLS_CC);
	field = fetch_field_desc(pm->mclass, Z_STRVAL_P(member) TSRMLS_CC);

	create_mono_object(mono_class_from_mono_type(field->type), &value, zvalue TSRMLS_CC);
	mono_field_set_value(pm->mobject, field, (void *) value);
}

static int 
property_exists(zval *object, zval *member, int check_empty TSRMLS_DC)
{
}

static void 
property_delete(zval *object, zval *member TSRMLS_DC)
{
}

static int 
objects_compare(zval *object1, zval *object2 TSRMLS_DC)
{
}


static inline union _zend_function *
constructor_get(zval *object TSRMLS_DC)
{
	return mono_constructor;
}

static MonoObject *
php_call_mono_method_ex(php_mono_object *intern, MonoMethod *method, void **params, 
						int param_count, zval **return_value TSRMLS_DC)
{
	MonoObject          *retval;
	MonoObject          *except;
	MonoObject          *tmp_param;
	int                  i;

	if (!method) {
		return NULL;
	}

	for (i = 0; i < param_count; ++i) {
		if (method->signature->param_count == (i+1) && 
			method->signature->params[i]->type == MONO_TYPE_SZARRAY) {
			MonoArray *szparams;
			MonoClass *class;
			int j;

			class = mono_class_from_mono_type(method->signature->params[i])->element_class;
			szparams = mono_array_new(domain, class, param_count - i);
			for (j = i; j < param_count; ++j) {
				void **p;
				create_mono_object(class,
								   &tmp_param, 
								   *(zval **) params[j]);

				p = (void **) mono_array_addr_with_size(szparams, 
														mono_class_array_element_size(class), 
														j - i);
				*p = (void *) tmp_param;
			}

			params[i] = szparams;
			break;
		}

		create_mono_object(mono_class_from_mono_type(method->signature->params[i]), 
						   &tmp_param, 
						   *(zval **) params[i] TSRMLS_CC);
		params[i] = (MonoObject *) tmp_param;
	}

	retval = mono_runtime_invoke(method, intern->mobject, params, &except);
	if (return_value && *return_value) {
		create_php_object(method->signature->ret->type, return_value, retval TSRMLS_CC);
	}

	return retval;
}

static int
get_php_type(MonoType *type)
{
	switch (type->type) {
	case MONO_TYPE_VOID:
		return IS_BOOL;
	case MONO_TYPE_CHAR:
	case MONO_TYPE_I1:
	case MONO_TYPE_U1:
	case MONO_TYPE_I2:
	case MONO_TYPE_U2:
	case MONO_TYPE_I4:
	case MONO_TYPE_U4:
	case MONO_TYPE_I8:
	case MONO_TYPE_U8:
	case MONO_TYPE_I:
	case MONO_TYPE_U:
	case MONO_TYPE_VALUETYPE:
		return IS_LONG;
	case MONO_TYPE_R4:
	case MONO_TYPE_R8:
		return IS_DOUBLE;
	case MONO_TYPE_STRING:
		return IS_STRING;
	case MONO_TYPE_ARRAY:
		return IS_ARRAY;
	case MONO_TYPE_BYREF:
	case MONO_TYPE_CLASS:
	case MONO_TYPE_OBJECT:
		return IS_OBJECT;
	}
}


static int
get_type(MonoType *t)
{
	return t->type;
}

typedef int (*php_mono_get_type_func_t)(MonoType *);
typedef int php_parameters_typespec;
typedef struct {
	php_parameters_typespec *typespec;
	int count;
	php_mono_get_type_func_t typeaccess;
} php_parameters;


static int 
types_match(MonoMethodSignature *sig, php_parameters *pparams)
{
	int i;

	if (sig->param_count > pparams->count) {
		return 0;
	}

	for (i = 0; i < sig->param_count; ++i) {
		if (sig->params[i]->type == MONO_TYPE_SZARRAY && (i+1) == sig->param_count) {
			MonoClass *class;

			class = mono_class_from_mono_type(sig->params[i])->element_class;
			if (class->byval_arg.type == MONO_TYPE_OBJECT || 
				pparams->typeaccess(&class->byval_arg) == pparams->typespec[i]) {
				return 1;
			}

			return 0;
		}

		if (sig->params[i]->type != MONO_TYPE_OBJECT &&
			pparams->typeaccess(sig->params[i]) != pparams->typespec[i]) {
			return 0;
		}
	}

	if (sig->param_count != pparams->count) {
		return 0;
	}

	return 1;
}


static MonoMethod *
lookup_mono_method_ex(MonoClass *class, const char *method_name, int method_name_len, 
					  php_parameters *params)
{
	MonoMethod          *method = NULL;
	MonoMethodSignature *sig;
	int                  i, j;

	for (i = 0; i < class->method.count; ++i) {
		method = class->methods[i];
		sig = method->signature;

		if (!strncmp(method_name, method->name, method_name_len)) {
			if (types_match(sig, params)) {
				return method;
			}
		}
	}

	return NULL;
}

static php_parameters_typespec *
typespec_from_args(void **params, int param_count) 
{
	php_parameters_typespec *p;
	zval **tmp;
	int i;

	p = emalloc(sizeof(php_parameters_typespec) * param_count);
	for (i = 0; i < param_count; ++i) {
		tmp = (zval **) params[i];
		p[i] = (int) Z_TYPE_PP(tmp);
	}
	return p;
}

static int
type_from_name(char *p, int len)
{

	if (len == 1) {
		if (!strncmp(p, "i", len)) {
			return MONO_TYPE_I;
		} else if (!strncmp(p, "u", len)) {
			return MONO_TYPE_U;
		}
	} else if (len == 2) {
		if (!strncmp(p, "i1", len)) {
			return MONO_TYPE_I1;
		} else if (!strncmp(p, "u1", len)) {
			return MONO_TYPE_U1;
		} else if (!strncmp(p, "i2", len)) {
			return MONO_TYPE_I2;
		} else if (!strncmp(p, "u2", len)) {
			return MONO_TYPE_U2;
		} else if (!strncmp(p, "i4", len)) {
			return MONO_TYPE_I4;
		} else if (!strncmp(p, "u4", len)) {
			return MONO_TYPE_U4;
		} else if (!strncmp(p, "i8", len)) {
			return MONO_TYPE_I8;
		} else if (!strncmp(p, "u8", len)) {
			return MONO_TYPE_U8;
		} else if (!strncmp(p, "r4", len)) {
			return MONO_TYPE_R4;
		} else if (!strncmp(p, "r8", len)) {
			return MONO_TYPE_R8;
		}
	} else {
		if (!strncmp(p, "boolean", len)) {
			return MONO_TYPE_BOOLEAN;
		} else if (!strncmp(p, "char", len)) {
			return MONO_TYPE_CHAR;
		} else if (!strncmp(p, "string", len)) {
			return MONO_TYPE_STRING;
		} else if (!strncmp(p, "valuetype", len)) {
			return MONO_TYPE_VALUETYPE;
		}
	}

	return MONO_TYPE_OBJECT;
}

static php_parameters_typespec *
typespec_from_signature(const char *method_signature, 
						int method_signature_len, 
						int *param_count)
{
	php_parameters_typespec *params = NULL;
	char *p, *end, *s = (char *) method_signature;
	int i = 0, len;

	/* Discard Method Name */
	p = memchr(s, ':', method_signature_len);

	/* Loop through arguments */
	while (p != NULL && (len = method_signature_len - ((p+1) - s))) {
		end = memchr(p+1, ':', len);
		if (end) {
			len = end - (p + 1);
		}
		
		params = erealloc(params, (i + 1) * sizeof(php_parameters_typespec));
		params[i] = type_from_name(p+1, len);
		++i;

		p = end;
	}

	*param_count = i;

	return params;
}

static MonoMethod *
lookup_mono_method(php_mono_object *intern, const char *method_signature, int method_signature_len,
				   const char *method_name, int method_name_len, void **params, int param_count TSRMLS_DC)
{
	MonoMethod *method;
	php_parameters_typespec *typespec;
	php_parameters pparams;

	if (method_signature) {
		typespec = typespec_from_signature(method_signature, method_signature_len, &param_count);
		pparams.typeaccess = get_type;
	} else {
		typespec = typespec_from_args(params, param_count);
		pparams.typeaccess = get_php_type;
	}

	pparams.typespec = typespec;
	pparams.count = param_count;

	method = lookup_mono_method_ex(intern->mclass, method_name, method_name_len, &pparams);
	efree(pparams.typespec);
	return method;
}

static char *
name_from_signature(const char *method_signature, int method_signature_len, int *name_len)
{
	const char *p;
	char *s = (char *) method_signature;

	p = memchr(s, ':', method_signature_len);
	*name_len = p - s;
	
	return s;
}

static MonoMethod *
find_method_with_signature(php_mono_object *intern, const char *method_signature, int method_signature_len,
						   void **params, int param_count TSRMLS_DC)
{
	MonoMethod *method;
	MonoMethod **lookup;
	char       *method_name;
	int         name_len;

	if (zend_hash_find(&MONOG(methods), (char *) method_signature, strlen(method_signature)+1, (void **) &lookup) == SUCCESS) {
		return *lookup;
	}

	method_name = name_from_signature(method_signature, method_signature_len, &name_len);

	method = lookup_mono_method(intern, 
								method_signature, 
								method_signature_len,
								method_name,
								name_len,
								params, 
								param_count 
								TSRMLS_CC);

	zend_hash_update(&MONOG(methods), (char *) method_signature, 
					 method_signature_len+1, 
					 (void **) &method, sizeof(MonoMethod *), NULL);

	return method;
}
	

static void 
create_signature(smart_str *s, MonoClass *m, const char *method_name, int method_name_len, void **params, int param_count)
{
	zval **tmp_param;
	int i;

	smart_str_appends(s, (char *) m->name_space);
	smart_str_appendc(s, '.');
	smart_str_appends(s, (char *) m->name);
	smart_str_appendc(s, '.');
	smart_str_appendl(s, (char *) method_name, method_name_len);
	for (i = 0; i < param_count; ++i) {
		smart_str_appendc(s, ':');
		tmp_param = (zval **) params[i];
		switch (Z_TYPE_PP(tmp_param)) {
		case IS_NULL:
			smart_str_appendc(s, 'n');
			break;
		case IS_BOOL:
			smart_str_appendc(s, 'b');
			break;
		case IS_LONG:
			smart_str_appendc(s, 'l');
			break;
		case IS_DOUBLE:
			smart_str_appendc(s, 'd');
			break;
		case IS_STRING:
			smart_str_appendc(s, 's');
			break;
		default:
			smart_str_appendc(s, 'o');
			break;
		}
	}
	smart_str_0(s);
}

static MonoMethod *
find_method(php_mono_object *intern, const char *method_name, int method_name_len, 
			void **params, int param_count TSRMLS_DC)
{
	MonoMethod  *method;
	MonoMethod **lookup;
	smart_str s = {0};

	create_signature(&s, intern->mclass, method_name, method_name_len, params, param_count);
	if (zend_hash_find(&MONOG(methods), s.c, s.len+1, (void **) &lookup) == SUCCESS) {
		return *lookup;
	}

	method = lookup_mono_method(intern, NULL, -1, method_name, method_name_len, params, param_count TSRMLS_CC);
	if (method == NULL) {
		return NULL;
	}
	zend_hash_update(&MONOG(methods), s.c, s.len+1, (void **) &method, sizeof(MonoMethod *), NULL);

	return method;
}

static MonoObject *
php_call_mono_method_with_signature(php_mono_object *intern, 
									const char *method_signature, 
									void **params, 
									int param_count, 
									zval **return_value TSRMLS_DC)
{
	MonoMethod *method;

	method = find_method_with_signature(intern, method_signature, strlen(method_signature), 
										params, param_count TSRMLS_CC);
	return php_call_mono_method_ex(intern, method, params, param_count, return_value TSRMLS_CC);
}

static MonoObject *
php_call_mono_method(php_mono_object *intern, const char *method_name, int method_name_len, void **params, int param_count,
					 zval **return_value TSRMLS_DC)
{
	MonoMethod *method;

	method = find_method(intern, method_name, method_name_len, params, param_count TSRMLS_CC);
	if (method == NULL) {
		if (strcmp(method_name, ".ctor")) {
			php_error(E_WARNING, "No Suitable method found");
		}
	}


	return php_call_mono_method_ex(intern, method, params, param_count, return_value TSRMLS_CC);
}

static union _zend_function *
method_get(zval *object, char *method_name, int method_len TSRMLS_DC)
{
	php_mono_object *pm;
	zend_internal_function *f;

	pm = php_mono_fetch_object(object TSRMLS_CC);
	
	f = emalloc(sizeof(zend_internal_function));
	f->type = ZEND_OVERLOADED_FUNCTION;
	f->arg_types = NULL;
	f->scope = pm->zo.ce;
	f->fn_flags = 0;
	f->function_name = estrndup(method_name, method_len);
																		
	return (union _zend_function *) f;
}

static int 
call_method(char *method, INTERNAL_FUNCTION_PARAMETERS)
{
	zval            ***argv;
	php_mono_object   *pm;
	int                argc = ZEND_NUM_ARGS();

	argv = (zval ***) emalloc(sizeof(zval **) * argc);
	if (zend_get_parameters_array_ex(argc, argv) == FAILURE) {
		php_error(E_WARNING, "COuldn't fetch arguments for %s into Mono __call handler", method);
		RETURN_NULL();
	}

	pm = php_mono_fetch_object(getThis() TSRMLS_CC);
	php_call_mono_method(pm, method, strlen(method), (void **) argv, argc, &return_value TSRMLS_CC);
	efree(argv);
}

static zval ** 
property_get_ptr(zval *object, zval *member TSRMLS_DC)
{
	zval **property_ptr;
	zval  *property;

	property_ptr = emalloc(sizeof(zval **));
	property = property_read(object, member TSRMLS_CC);
	zval_add_ref(&property);

	*property_ptr = property;

	return property_ptr;
}


static zend_class_entry *
class_entry_get(zval *zobject TSRMLS_DC)
{
	return mono_class_entry;
}

static void
cast_object(zval *readobj, zval *writeobj, int type, int should_free TSRMLS_DC)
{
	php_mono_object *pm;

	pm = php_mono_fetch_object(readobj TSRMLS_CC);

	switch (type) {
		case IS_STRING:
			php_call_mono_method(pm, "ToString", sizeof("ToString")-1, (void **) NULL, 0, &writeobj TSRMLS_CC);
			break;
		case IS_LONG:
			php_call_mono_method(pm, "ToInteger", sizeof("ToInteger")-1, (void **) NULL, 0, &writeobj TSRMLS_CC);
			break;
		case IS_DOUBLE:
			php_call_mono_method(pm, "ToDouble", sizeof("ToDouble")-1, (void **) NULL, 0, &writeobj TSRMLS_CC);
			break;
	} 
}

static zend_object_handlers mono_object_handlers[] = {
	ZEND_OBJECTS_STORE_HANDLERS,
	property_read,
	property_write,
	property_get_ptr,
	property_get_ptr,
	NULL,
	NULL,
	property_exists,
	property_delete,
	NULL,
	method_get,
	call_method,
	constructor_get,
	class_entry_get,
	NULL,
	objects_compare,
	cast_object
};

static void
object_clone(void *object, void **object_clone TSRMLS_DC)
{
	php_mono_object  *pm = (php_mono_object *) object;
	php_mono_object **pm_clone = (php_mono_object **) object_clone;
	
	*pm_clone = emalloc(sizeof(php_mono_object));
	(*pm_clone)->zo.ce = pm->zo.ce;
	(*pm_clone)->zo.in_get = (*pm_clone)->zo.in_set = 0;

	ALLOC_HASHTABLE((*pm_clone)->zo.properties);
	zend_hash_init((*pm_clone)->zo.properties, 0, NULL, ZVAL_PTR_DTOR, 0);
	zend_hash_copy((*pm_clone)->zo.properties, pm->zo.properties, (copy_ctor_func_t) zval_add_ref,
				   (void *) NULL, sizeof(zval *));
	
	(*pm_clone)->mimage = pm->mimage;
	(*pm_clone)->mclass = pm->mclass;
	(*pm_clone)->mobject = mono_object_clone(pm->mobject);
}

static void
object_dtor(void *object, zend_object_handle handle TSRMLS_DC)
{
	php_mono_object *pm;
	zend_objects_destroy_object(object, handle TSRMLS_CC);
}

static zend_object_value 
object_new(zend_class_entry *ce TSRMLS_DC)
{
	zend_object_value return_value;
	php_mono_object  *intern;
	zval             *tmp;

	intern = emalloc(sizeof(php_mono_object));
	intern->zo.ce = ce;
	intern->zo.in_get = 0;
	intern->zo.in_set = 0;

	ALLOC_HASHTABLE(intern->zo.properties);
	zend_hash_init(intern->zo.properties, 0, NULL, ZVAL_PTR_DTOR, 0);

	return_value.handle = zend_objects_store_put(intern, object_dtor, object_clone);
	return_value.handlers = (zend_object_handlers *) &mono_object_handlers;

	return return_value;
}

static MonoImage *
create_mono_image(const char *filename TSRMLS_DC)
{
	MonoImage           *image;
	MonoImage          **lookup;
	MonoImageOpenStatus  status;

	if (zend_hash_find(&MONOG(images), (char *) filename, strlen(filename)+1, (void **) &lookup) == SUCCESS) {
		return *lookup;
	}

	image = mono_image_open(filename, &status);
	if (image == NULL) {
		php_error(E_WARNING, "Couldn't open image: %s", mono_image_strerror(status));
		return NULL;
	}

	zend_hash_update(&MONOG(images), (char *) filename, strlen(filename)+1, 
					 (void **) &image, sizeof(MonoImage *), NULL);

	return image;
}

static void
parse_class_name(const char *class_unparsed, char **namespace, char **class_name)
{
	char *p;
	
	p = strrchr(class_unparsed, '.');
	if (p == NULL) {
		*namespace = NULL;
		*class_name = (char *) class_unparsed;
		return;
	}
	
	*namespace = (char *) class_unparsed;
	(*namespace)[p - class_unparsed] = '\0';
	*class_name = p + 1;
}

static MonoClass *
create_mono_class(MonoImage *image, const char *class_unparsed, char **namespace, char **class_name TSRMLS_DC)
{
	MonoClass *c;
	MonoClass **lookup;

	/* XXX: Insert a global class caching mechanism to avoid
	 * doing this every single request
	 */

	if (zend_hash_find(&MONOG(classes), (char *) class_unparsed, strlen(class_unparsed)+1, 
					   (void **) &lookup) == SUCCESS) {
		return *lookup;
	}

	parse_class_name(class_unparsed, namespace, class_name);

	c = mono_class_from_name(image, *namespace, *class_name);
	if (c == NULL) {
		php_error(E_WARNING, "Cannot find class description for %s", class_unparsed);
		return NULL;
	}
	mono_class_init(c);

	zend_hash_update(&MONOG(classes), (char *) class_unparsed, strlen(class_unparsed)+1, (void **) &c, 
					 sizeof(MonoClass *), NULL);

	return c;
}

typedef struct {
	zend_object zo;
	php_mono_object *obj;
	MonoMethod *method;
} php_mono_method_intern;

static void
create_php_method(zval **return_value, php_mono_object *intern, MonoMethod *method TSRMLS_DC)
{
	php_mono_method_intern *method_obj;

	method_obj = emalloc(sizeof(php_mono_method_intern));
	method_obj->zo.ce = mono_method_class_entry;
	method_obj->zo.in_get = 0;
	method_obj->zo.in_set = 0;

	ALLOC_HASHTABLE(method_obj->zo.properties);
	zend_hash_init(method_obj->zo.properties, 0, NULL, ZVAL_PTR_DTOR, 0);

	method_obj->obj = intern;
	method_obj->method = method;

	(*return_value)->type = IS_OBJECT;
	(*return_value)->value.obj.handle = zend_objects_store_put(method_obj, NULL, NULL);
	(*return_value)->value.obj.handlers = (zend_object_handlers *) zend_get_std_object_handlers();
}

ZEND_FUNCTION(mono_method_call)
{
	zval            ***argv;
	php_mono_method_intern *method_obj;
	int                argc = ZEND_NUM_ARGS();
	
	argv = (zval ***) emalloc(sizeof(zval **) * argc);
	if (zend_get_parameters_array_ex(argc, argv) == FAILURE) {
		php_error(E_WARNING, "COuldn't fetch arguments into array in Mono Call handler");
		RETURN_NULL();
	}

	if (getThis() == NULL) {
		php_error(E_WARNING, "No object found in method call");
		RETURN_NULL();
	}
	
	method_obj = (php_mono_method_intern *) zend_object_store_get_object(getThis() TSRMLS_CC);
	php_call_mono_method_ex(method_obj->obj, method_obj->method, (void **) argv, argc, 
							&return_value TSRMLS_CC);
	efree(argv);
}

ZEND_FUNCTION(mono_method_find)
{
	php_mono_object *intern;
	zval            *resource;
	MonoMethod      *method;
	MonoMethod     **lookup;
	char            *signature;
	int              signature_len;
	int              argc = ZEND_NUM_ARGS();

	if ((resource = getThis()) == NULL) {
		if (zend_parse_parameters(argc TSRMLS_CC, "zs", 
								  &resource, &signature, &signature_len) == FAILURE) {
			return;
		}
	} else {
		if (zend_parse_parameters(argc TSRMLS_CC, "s", &signature, &signature_len) == FAILURE) {
			return;
		}
	}

	intern = php_mono_fetch_object(resource TSRMLS_CC);

	if (zend_hash_find(&MONOG(methods), signature, signature_len+1, (void **) &lookup) == SUCCESS) {
		create_php_method(&return_value, intern, *lookup TSRMLS_CC);
		return;
	}

	method = find_method_with_signature(intern, 
										signature, 
										signature_len,
										NULL,
										-1 TSRMLS_CC);
	if (method == NULL) {
		RETURN_FALSE;
	}

	zend_hash_update(&MONOG(methods), signature, signature_len+1, 
					 (void **) &method, sizeof(MonoMethod *), NULL);

	create_php_method(&return_value, intern, method TSRMLS_CC);
}	

ZEND_FUNCTION(mono_load)
{
	php_mono_object  *intern;
	zval             *params = NULL;
	zval            **element;
	HashPosition      pos;
	void            **new_params = NULL;
	char             *namespace, *classname, *imagename, *collection_name;
	int               collection_name_len, imagename_len = 0, param_count = 0;
	int               argc = ZEND_NUM_ARGS(), i;
	
	if (zend_parse_parameters(argc TSRMLS_CC, "s|sz", &collection_name, &collection_name_len,
				&imagename, &imagename_len, &params) == FAILURE) {
		return;
	}

	intern = php_mono_fetch_object(getThis() TSRMLS_CC);
	if (argc < 2 || imagename_len == 0) {
		intern->mimage = mono_defaults.corlib;
	}
	else {
		intern->mimage = create_mono_image(imagename TSRMLS_CC);
	}
	intern->mclass = create_mono_class(intern->mimage, collection_name, &namespace, &classname TSRMLS_CC);
	intern->mobject = mono_object_new(domain, intern->mclass);

	if (params && Z_ARRVAL_P(params) && (param_count = zend_hash_num_elements(Z_ARRVAL_P(params)))) {
		new_params = emalloc(sizeof(void *) * param_count);
		for (i = 0, zend_hash_internal_pointer_reset_ex(Z_ARRVAL_P(params), &pos);
			 zend_hash_get_current_data_ex(Z_ARRVAL_P(params), (void **) &element, &pos) == SUCCESS;
			 zend_hash_move_forward_ex(Z_ARRVAL_P(params), &pos), ++i) {
			new_params[i] = (void *) element;
		}
	}

	php_call_mono_method(intern, ".ctor", sizeof(".ctor")-1, new_params, param_count, NULL TSRMLS_CC);
	if (new_params) {
		efree(new_params);
	}
}

static void
create_globals(zend_mono_globals *mono_globals)
{
	zend_hash_init(&mono_globals->methods, 5, NULL, NULL, 0);
	zend_hash_init(&mono_globals->classes, 5, NULL, NULL, 0);
	zend_hash_init(&mono_globals->images, 5, NULL, NULL, 0);
}

static void
destroy_globals(zend_mono_globals *mono_globals)
{
	zend_hash_clean(&mono_globals->methods);
	zend_hash_clean(&mono_globals->classes);
	zend_hash_clean(&mono_globals->images);
}

ZEND_MINIT_FUNCTION(mono)
{
	zend_class_entry       mono_class;
	zend_class_entry       mono_method_class;
	zend_internal_function constructor;
	zend_internal_function method_call;

	ZEND_INIT_MODULE_GLOBALS(mono, create_globals, destroy_globals);
	
	INIT_CLASS_ENTRY(mono_class, "mono", NULL);
	mono_class.create_object = object_new;
	mono_class_entry = zend_register_internal_class(&mono_class TSRMLS_CC);

	constructor.type = ZEND_INTERNAL_FUNCTION;
	constructor.function_name = "mono";
	constructor.scope = mono_class_entry;
	constructor.arg_types = NULL;
	constructor.handler = ZEND_FN(mono_load);

	zend_hash_add(&mono_class_entry->function_table, "mono", 
			sizeof("mono"), &constructor, sizeof(zend_function), 
			(void *) &mono_constructor);

	INIT_CLASS_ENTRY(mono_method_class, "__mono_method", NULL);
	mono_method_class_entry = zend_register_internal_class(&mono_method_class TSRMLS_CC);

	method_call.type = ZEND_INTERNAL_FUNCTION;
	method_call.function_name = "call";
	method_call.scope = mono_method_class_entry;
	method_call.arg_types = NULL;
	method_call.handler = ZEND_FN(mono_method_call);

	zend_hash_add(&mono_method_class_entry->function_table, "call",
				  sizeof("call"), &method_call, sizeof(zend_function), 
				  (void *) &mono_method_call);

	domain = mono_jit_init("PHP");
	if (domain == NULL) {
		php_error(E_WARNING, "Domain not initialized");
		return FAILURE;
	}

	return SUCCESS;
}


ZEND_MSHUTDOWN_FUNCTION(mono)
{
	mono_jit_cleanup(domain);
	return SUCCESS;
}



ZEND_RINIT_FUNCTION(mono)
{
	return SUCCESS;
}



ZEND_RSHUTDOWN_FUNCTION(mono)
{
	return SUCCESS;
}


ZEND_MINFO_FUNCTION(mono)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "mono support", "enabled");
	php_info_print_table_end();

}

zend_function_entry mono_functions[] = {
	ZEND_FE(mono_method_find, NULL)
	ZEND_FE(mono_method_call, NULL)
	{NULL, NULL, NULL}
};


zend_module_entry mono_module_entry = {
	STANDARD_MODULE_HEADER,
	"mono",
	mono_functions,
	ZEND_MINIT(mono),
	ZEND_MSHUTDOWN(mono),
	ZEND_RINIT(mono),	
	ZEND_RSHUTDOWN(mono),
	ZEND_MINFO(mono),
	"0.1",
	STANDARD_MODULE_PROPERTIES
};


#ifdef COMPILE_DL_MONO
ZEND_GET_MODULE(mono)
#endif


#endif

/**
 * Local Variables:
 * c-basic-offset: 4
 * tab-width: 4
 * End:
 * vim600: fdm=marker
 * vim: noet sw=4 ts=4
 */

