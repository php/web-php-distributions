new XML_Parser string(10) "xml_parser"
error message: XML_Parser: mismatched tag at XML input line 1
