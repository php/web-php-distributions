<?php
$Console = new Mono('System.Console');

$Console->WriteLine('{0} {1} {2} {3} {4} {5} {6}', 
	'hello', 'world,', 'this', 'is', 'a', 'big', 'test!');
?>
