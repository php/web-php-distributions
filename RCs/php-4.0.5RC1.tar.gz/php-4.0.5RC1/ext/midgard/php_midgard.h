/* $Id: php_midgard.h,v 1.8 2001/03/10 22:43:10 emile Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef PHP_MIDGARD_H
#define PHP_MIDGARD_H

/* You should tweak config.m4 so this symbol (or some else suitable)
   gets defined.
*/
#include <php_config.h>

#if HAVE_MIDGARD

#include <php.h>
#include <midgard/midgard.h>
#include <midgard/apache.h>
/* #include <Zend/zend_modules.h> */

midgard_request_config *mgd_rcfg();
midgard_directory_config *mgd_dcfg();
midgard *mgd_handle();
zval *mgd_getudf();
int mgd_get_errno();
void mgd_reset_errno();
void mgd_set_errno(int mgd_errno);
void mgd_log_debug(int flags, const char *fmt, ...);

extern zend_module_entry midgard_module_entry;
#define phpext_midgard_ptr &midgard_module_entry

#ifdef PHP_WIN32
#define PHP_MIDGARD_API __declspec(dllexport)
#else
#define PHP_MIDGARD_API
#endif

PHP_MINIT_FUNCTION(midgard);
PHP_MSHUTDOWN_FUNCTION(midgard);
PHP_RINIT_FUNCTION(midgard);
PHP_RSHUTDOWN_FUNCTION(midgard);
PHP_MINFO_FUNCTION(midgard);

PHP_FUNCTION(confirm_midgard_compiled);	/* For testing, remove later. */

ZEND_BEGIN_MODULE_GLOBALS(midgard)
	midgard_request_config *rcfg;
	midgard_directory_config *dcfg;
   midgard *mgd;
   int mgd_errno;
   zval *udf;
ZEND_END_MODULE_GLOBALS(midgard)

/* In every function that needs to use variables in php_midgard_globals,
   do call MGDLS_FETCH(); after declaring other variables used by
   that function, and always refer to them as MGDG(variable).
   You are encouraged to rename these macros something shorter, see
   examples in any other php module directory.
*/

#ifdef ZTS
#define MGDG(v) (midgard_globals->v)
#define MGDLS_FETCH() php_midgard_globals *midgard_globals = ts_resource(midgard_globals_id)
#else
#define MGDG(v) (midgard_globals.v)
#define MGDLS_FETCH()
#endif

#else

#define phpext_midgard_ptr NULL

#endif

#endif	/* PHP_MIDGARD_H */


/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 */
