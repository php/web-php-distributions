/* $Id: snippet.c,v 1.7 2001/03/10 22:43:10 emile Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mgd_internal.h"
#include "mgd_oop.h"

MGD_FUNCTION(ret_type, snippet_exists, (type param))
{
	zval **file;
	int upval, idval;
	midgard *mgd = mgd_handle(); // DG: GLOBAL(midgard_module_env).mgd;
	
	RETVAL_FALSE;
	if (ZEND_NUM_ARGS() == 1) {
		if( zend_get_parameters_ex(1,&file) == FAILURE ) {
			WRONG_PARAM_COUNT;
		} else {
			convert_to_string_ex(file);
		}
	} else WRONG_PARAM_COUNT;

	if (MGD_PARSE_COMMON_PATH(mgd, (*file)->value.str.val,
					"snippetdir", "snippet", &idval, &upval))
		return;
	
	if(idval) RETURN_TRUE;
}

MGD_FUNCTION(ret_type, list_snippets, (type param))
{
    IDINIT;
	CHECK_MGD;
    php_midgard_select(&MidgardSnippet, return_value, "id,name,author,creator,created,revisor,revised,revision" SITEGROUP_SELECT, "snippet", "up=$d", "name", id);
}

MGD_FUNCTION(ret_type, get_snippet, (type param))
{
	zval **id;
	CHECK_MGD;

	switch (ZEND_NUM_ARGS()) {
	case 0:
		php_midgard_bless(return_value, &MidgardSnippet);
		mgd_object_init(return_value, "up", "name", "code", "doc", "author", NULL);
		return;
	case 1:
		if (zend_get_parameters_ex(1, &id) == SUCCESS) {
			convert_to_long_ex(id);
			break;
		} /* else fall through */
	default:
		WRONG_PARAM_COUNT;
	}
	if(!(*id)->value.lval)
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

    php_midgard_get_object(return_value, MIDGARD_OBJECT_SNIPPET, (*id)->value.lval);
}

MGD_FUNCTION(ret_type, get_snippet_by_name, (type param))
{
    zval **snippetdir, **name;
	CHECK_MGD;
    if (ZEND_NUM_ARGS() != 2
	|| zend_get_parameters_ex(2, &snippetdir, &name) != SUCCESS)
	WRONG_PARAM_COUNT;
    convert_to_long_ex(snippetdir);
    convert_to_string_ex(name);

	if(!(*snippetdir)->value.lval || !(*name)->value.str.len)
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
    php_midgard_get_by_name(&MidgardSnippet, return_value, "id,up,name,code,doc,author,creator,revisor,revised,revision", "snippet", "up",
			    (*snippetdir)->value.lval,(*name)->value.str.val);
}

MGD_FUNCTION(ret_type, create_snippet, (type param))
{
	zval **snippetdir, **name, **code, **doc, **author, *self;

	RETVAL_FALSE;
	CHECK_MGD;

	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 0) {
			WRONG_PARAM_COUNT;
		}

		if (!MGD_PROPFIND(self, "up", snippetdir)
		    || !MGD_PROPFIND(self, "name", name)
		    || !MGD_PROPFIND(self, "code", code)
		    || !MGD_PROPFIND(self, "doc", doc)
		    || !MGD_PROPFIND(self, "author", author)
		   ) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		self = NULL;
		if (ZEND_NUM_ARGS() != 5
		    || zend_get_parameters_ex(5, &snippetdir, &name, &code, &doc,
				     &author) == FAILURE)
			WRONG_PARAM_COUNT;
	}

	convert_to_long_ex(snippetdir);
	convert_to_string_ex(name);
	convert_to_string_ex(code);
	convert_to_string_ex(doc);
	convert_to_string_ex(author);

	if (!mgd_exists_id(mgd_handle(), "person", "id=$d", (*author)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	if (!mgd_exists_id(mgd_handle(), "snippetdir", "id=$d", (*snippetdir)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	if (!issnippetdirowner((*snippetdir)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

   if (mgd_exists_id(mgd_handle(), "snippet", "up=$d AND name=$q",
			     (*snippetdir)->value.lval, (*name)->value.str.val))
		RETURN_FALSE_BECAUSE(MGD_ERR_DUPLICATE);

	php_midgard_create(return_value, "snippet",
			   "up,name,code,doc,author,creator,created,revisor,revised,revision",
			   "$d,$q,$q,$q,$q,$d,Now(),$d,Now(),0",
			   (*snippetdir)->value.lval, (*name)->value.str.val,
			   (*code)->value.str.val, (*doc)->value.str.val,
			   (*author)->value.str.val, mgd_user(mgd_handle()),
			   mgd_user(mgd_handle()));

	PHP_CREATE_REPLIGARD("snippet", return_value->value.lval);
}

MGD_FUNCTION(ret_type, update_snippet, (type param))
{
	zval **id, **name, **code, **doc, **author, *self;
	int up;

	RETVAL_FALSE;
	CHECK_MGD;

	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 0) {
			WRONG_PARAM_COUNT;
		}

		if (!MGD_PROPFIND(self, "id", id)
		    || !MGD_PROPFIND(self, "name", name)
		    || !MGD_PROPFIND(self, "code", code)
		    || !MGD_PROPFIND(self, "doc", doc)
		   ) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
      
	convert_to_long_ex(id);
	convert_to_string_ex(name);
	convert_to_string_ex(code);
	convert_to_string_ex(doc);
	author = NULL;
      if (mgd_isadmin(mgd_handle())) {
         if (!MGD_PROPFIND(self, "author", author)) {
            RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
         }
	convert_to_string_ex(author);
      }
	}
	else {
		switch (ZEND_NUM_ARGS()) {
			case 4:
				if (zend_get_parameters_ex
				    (4, &id, &name, &code, &doc) == FAILURE) {
					WRONG_PARAM_COUNT;
				}
				convert_to_long_ex(id);
				convert_to_string_ex(name);
				convert_to_string_ex(code);
				convert_to_string_ex(doc);
				author = NULL;
				break;

			case 5:
				if (!mgd_isadmin(mgd_handle())
				    || zend_get_parameters_ex(5, &id, &name, &code,
						     &doc, &author) == FAILURE) {
					WRONG_PARAM_COUNT;
				}
				convert_to_long_ex(id);
				convert_to_string_ex(name);
				convert_to_string_ex(code);
				convert_to_string_ex(doc);
				convert_to_string_ex(author);
				break;

			default:
				WRONG_PARAM_COUNT;
		}
	}

	if (!mgd_exists_id(mgd_handle(), "snippet", "id=$d", (*id)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	if (!issnippetdirowner
	    (up =
	     mgd_idfield(mgd_handle(), "up", "snippet",
			 (*id)->value.lval)))
	      RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
	if (mgd_exists_id
	    (mgd_handle(), "snippet", "id!=$d AND up=$d AND name=$q",
	     (*id)->value.lval, up, (*name)->value.str.val))
		RETURN_FALSE_BECAUSE(MGD_ERR_DUPLICATE);

	if (author)
		php_midgard_update(return_value, "snippet",
				   "name=$q,code=$q,doc=$q,author=$q,revisor=$d,revised=Now(),revision=revision+1",
				   (*id)->value.lval, (*name)->value.str.val,
				   (*code)->value.str.val, (*doc)->value.str.val,
				   (*author)->value.str.val,
				   mgd_user(mgd_handle()));
	else
		php_midgard_update(return_value, "snippet",
				   "name=$q,code=$q,doc=$q,revisor=$d,revised=Now(),revision=revision+1",
				   (*id)->value.lval, (*name)->value.str.val,
				   (*code)->value.str.val, (*doc)->value.str.val,
				   mgd_user(mgd_handle()));
	PHP_UPDATE_REPLIGARD("snippet", (*id)->value.lval);
}

MGD_FUNCTION(ret_type, delete_snippet, (type param))
{
	IDINIT;
	CHECK_MGD;

	if (mgd_has_dependants(mgd_handle(), id, "snippet"))
		RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);

	if (!issnippetdirowner(mgd_idfield(mgd_handle(), "up", "snippet", id)))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	php_midgard_delete(return_value, "snippet", id);
	PHP_DELETE_REPLIGARD("snippet", id);
}

MGD_FUNCTION(ret_type, copy_snippet, (type param))
{
	zval **id, **newsnippetdir;
	RETVAL_FALSE;
	CHECK_MGD;
	switch (ZEND_NUM_ARGS()) {
		case 2:
			if (zend_get_parameters_ex(2, &id, &newsnippetdir) !=
			    SUCCESS) WRONG_PARAM_COUNT;
			break;
		case 1:
			if (zend_get_parameters_ex(1, &id) != SUCCESS)
				WRONG_PARAM_COUNT;
			newsnippetdir = NULL;
			break;
		default:
			WRONG_PARAM_COUNT;
	}

	convert_to_long_ex(id);
	if (newsnippetdir)
		convert_to_long_ex(newsnippetdir);

#if HAVE_MIDGARD_SITEGROUPS
	/* newsnippetdir must be in same SG or be 0 */
	if (newsnippetdir && !mgd_exists_bool(mgd_handle(), "snippetdir,snippet",
				    "snippetdir.id=$d AND snippet.id=$d"
				    " AND (snippetdir.sitegroup=snippet.sitegroup"
				    " OR snippetdir.sitegroup=0"
				    " OR snippet.sitegroup=0)",
				    (*newsnippetdir)->value.lval, (*id)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_SITEGROUP_VIOLATION);
#endif

	RETVAL_LONG(mgd_copy_snippet(mgd_handle(), (*id)->value.lval,
				     newsnippetdir ? (*newsnippetdir)->value.lval : 0));

}

MGD_MOVE_FUNCTION(snippet,snippetdir,snippet,up);

MidgardProperty MidgardSnippetProperties [] = {
	{ IS_LONG,		"up"		},
	{ IS_STRING,	"name"		},
	{ IS_STRING,	"code"		},
	{ IS_STRING,	"doc"		},
	{ IS_STRING,	"author"	},
	{ 0,			NULL		}
};

MIDGARD_CLASS(MidgardSnippet, snippet)
