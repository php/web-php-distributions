/* $Id: element.c,v 1.7 2001/03/10 22:43:10 emile Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mgd_internal.h"
#include "mgd_access.h"
#include "mgd_oop.h"

MGD_FUNCTION(ret_type, list_elements, (type param))
{
	IDINIT;
	CHECK_MGD;
	php_midgard_select(&MidgardElement, return_value,
			   "id,name" SITEGROUP_SELECT, "element", "style=$d", "name", id);
}

MGD_FUNCTION(ret_type, get_element, (type param))
{
	zval **id;
	zval **style, **name;
	CHECK_MGD;

	switch (ZEND_NUM_ARGS()) {
		case 0:
			php_midgard_bless(return_value, &MidgardElement);
			mgd_object_init(return_value, "id", "style", "name",
					 "value", NULL);
			return;
		case 1:
			if (zend_get_parameters_ex(1, &id) != SUCCESS) {
				WRONG_PARAM_COUNT;
			}
			convert_to_long_ex(id);

         php_midgard_get_object(return_value, MIDGARD_OBJECT_ELEMENT, (*id)->value.lval);
			break;
		case 2:
			if (zend_get_parameters_ex(2, &style, &name) != SUCCESS) {
				WRONG_PARAM_COUNT;
			}
			convert_to_long_ex(style);
			convert_to_string_ex(name);
			php_midgard_get_by_name(&MidgardElement,
						return_value,
						"id,style,name,value",
						"element", "style",
						(*style)->value.lval,
						(*name)->value.str.val);
			break;
		default:
			WRONG_PARAM_COUNT;
	}
}

MGD_FUNCTION(ret_type, get_element_by_name, (type param))
{
	/* EEH: just an alias for get_element */
	php_if_mgd_get_element(INTERNAL_FUNCTION_PARAM_PASSTHRU);
}

MGD_FUNCTION(ret_type, create_element, (type param))
{
	zval **style, **name, **value, *self;

	RETVAL_FALSE;
	CHECK_MGD;

	if ((self = getThis()) != NULL) {
		if (!MGD_PROPFIND(self, "style", style)
		    || !MGD_PROPFIND(self, "name", name)
		    || !MGD_PROPFIND(self, "value", value)) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if (ZEND_NUM_ARGS() != 3
		    || zend_get_parameters_ex(3, &style, &name,
					      &value) == FAILURE) {
			WRONG_PARAM_COUNT;
		}
	}

	convert_to_long_ex(style);
	convert_to_string_ex(name);
	convert_to_string_ex(value);

	if (!(*style)->value.lval
	    || !mgd_exists_id(mgd_handle(), "style", "id=$d",
			   (*style)->value.lval))
		   RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	if (!isstyleowner((*style)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	if (mgd_exists_id(mgd_handle(), "element", "style=$d AND name=$q",
		       (*style)->value.lval, (*name)->value.str.val))
		RETURN_FALSE_BECAUSE(MGD_ERR_DUPLICATE);

	php_midgard_create(return_value,
			   "element", "style,name,value",
			   "$d,$q,$q", (*style)->value.lval,
			   (*name)->value.str.val, (*value)->value.str.val);
	PHP_CREATE_REPLIGARD("element", return_value->value.lval);
}

MGD_FUNCTION(ret_type, update_element, (type param))
{
	zval **id, **name, **value, *self;

	RETVAL_FALSE;
	CHECK_MGD;

	if ((self = getThis()) != NULL) {
		if (!MGD_PROPFIND(self, "id", id)
		    || !MGD_PROPFIND(self, "name", name)
		    || !MGD_PROPFIND(self, "value", value)) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if (ZEND_NUM_ARGS() != 3
		    || zend_get_parameters_ex(3, &id, &name, &value) == FAILURE) {
			WRONG_PARAM_COUNT;
		}
	}
	convert_to_long_ex(id);
	convert_to_string_ex(name);
	convert_to_string_ex(value);

	if (!isstyleowner(mgd_idfield(mgd_handle(), "style", "element",
				      (*id)->value.lval)))
		   RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	php_midgard_update(return_value, "element", "name=$q,value=$q",
			   (*id)->value.lval,
			   (*name)->value.str.val, (*value)->value.str.val);
	PHP_UPDATE_REPLIGARD("element", (*id)->value.lval);
}

MGD_FUNCTION(ret_type, delete_element, (type param))
{
	IDINIT;
	CHECK_MGD;
	if (mgd_has_dependants(mgd_handle(), id, "element"))
		RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);

	if (!isstyleowner(mgd_idfield(mgd_handle(), "style", "element", id)))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	php_midgard_delete(return_value, "element", id);
	PHP_DELETE_REPLIGARD("element", id);
}

MGD_FUNCTION(ret_type, copy_element, (type param))
{
	zval **id, **newstyle;
	RETVAL_FALSE;
	CHECK_MGD;
	switch (ZEND_NUM_ARGS()) {
		case 2:
			if (zend_get_parameters_ex(2, &id, &newstyle) !=
			    SUCCESS) WRONG_PARAM_COUNT;
			break;
		case 1:
			if (zend_get_parameters_ex(1, &id) != SUCCESS)
				WRONG_PARAM_COUNT;
			newstyle = NULL;
			break;
		default:
			WRONG_PARAM_COUNT;
	}

	convert_to_long_ex(id);
	if (newstyle)
		convert_to_long_ex(newstyle);

#if HAVE_MIDGARD_SITEGROUPS
	/* newstyle must be in same SG or be 0 */
	if (newstyle && !mgd_exists_bool(mgd_handle(), "style,element",
				    "style.id=$d AND element.id=$d"
				    " AND (style.sitegroup=element.sitegroup"
				    " OR style.sitegroup=0"
				    " OR element.sitegroup=0)",
				    (*newstyle)->value.lval, (*id)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_SITEGROUP_VIOLATION);
#endif

	RETVAL_LONG(mgd_copy_element(mgd_handle(), (*id)->value.lval,
				     newstyle ? (*newstyle)->value.lval : 0));

}

MGD_MOVE_FUNCTION(element, style, element, style)

MidgardProperty MidgardElementProperties [] = {
	{ IS_LONG,		"style"		},
	{ IS_STRING,	"name"		},
	{ IS_STRING,	"value"		},
	{ 0,			NULL		}
};
MIDGARD_CLASS(MidgardElement, element)

