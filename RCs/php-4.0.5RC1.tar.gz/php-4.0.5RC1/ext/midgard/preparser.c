/* $Id: preparser.c,v 1.7 2001/02/28 01:00:32 davidg Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "php.h"
#include "php_ini.h"
//#include "../../php-4.0.4/Zend/zend_hilight.h"
#include "zend_highlight.h"
#include "ext/standard/basic_functions.h"
#include "php_midgard.h"
#include "mgd_internal.h"
#include "mgd_preparser.h"
//#include "internal_functions.h"

#if HAVE_MIDGARD

#include <midgard/apache.h>
#include <midgard/select_db.h>

#include "midgard/midgard.h"

void php_mgd_call_udf_function(char *type, zval *return_value, zval *arg)
{
	zval retval, **function_name;
	zval *udf = mgd_getudf();

	if(!return_value) {
		INIT_ZVAL(retval);
		return_value = &retval;
	}

	if(zend_hash_find(udf->value.ht, type,
						   strlen(type)+1,
						   (void **)&function_name) != SUCCESS) {
		php_error(E_WARNING,"Unknown user formatter [x]%s", type);
		RETURN_FALSE;
	}	
//	*return_value = **function_name; zval_copy_ctor(return_value);
	
	RETVAL_FALSE;
	if (call_user_function(CG(function_table), NULL, *function_name,
				return_value, 1, &arg) != SUCCESS) {
		php_error(E_WARNING,"Unable to call %s() - function does not exist",
				  (*function_name)->value.str.val);
		RETURN_FALSE;
	}
}

char * php_midgard_include(midgard_pool * pool, char * name, char * value, char * type)
{
	midgard *mgd;

	if ((mgd = mgd_handle()) == NULL) {
		php_error(E_NOTICE, "Not a midgard request");
		return NULL;
	}

	if(!pool && type[0]=='i') { /* inline */
		return value;
	}

	if (!type) {
		return mgd_format(mgd, pool, "$p", value);
	}

	if (strcmp(type, "u") == 0
			|| strcmp(type, "url") == 0)
		return mgd_format(mgd, pool, "$u", value);
	else if (strcmp(type, "f") == 0
		 || strcmp(type, "format") == 0)
		return mgd_format(mgd, pool, "$f", value);
	else if (strcmp(type, "F") == 0
		 || strcmp(type, "format-more") == 0)
		return mgd_format(mgd, pool, "$F", value);
	else if (strcmp(type, "t") == 0
		 || strcmp(type, "text") == 0)
		return mgd_format(mgd, pool, "$h", value);
	else if (strcmp(type, "T") == 0
		 || strcmp(type, "quote-all") == 0)
		return mgd_format(mgd, pool, "$p", value);
	else if (strcmp(type, "h") == 0
		 || strcmp(type, "html") == 0)
		return mgd_format(mgd, pool, "$H", value);
	else
		php_error(E_NOTICE, "Unknown format type %s", type);

	return NULL;
}

char * php_midgard_template(midgard_pool * pool, char * name)
{
	char *value = NULL;
	midgard_request_config *rcfg = mgd_rcfg();

	if (mgd_handle() == NULL) {
		php_error(E_ERROR, "Not a midgard request.");
		return NULL;
	}

/* TODO: check this when enabling FTs
	if (MGD_ENV.ft.elements) {
		value = g_hash_table_lookup(MGD_ENV.ft.elements, name);
	}
*/

	if (value == NULL && rcfg != NULL)
		value = (char *)ap_table_get(rcfg->elements, name);

	if (value == NULL) {
		return NULL;
	}

	return value;
}

MGD_FUNCTION(ret_type, template, (type param))
{
	zval **arg;
	char *tmp;
	midgard_pool * pool;

	if (ZEND_NUM_ARGS() != 1 || zend_get_parameters_ex(1,&arg)==FAILURE) {
		WRONG_PARAM_COUNT;
	}
	convert_to_string_ex(arg);
	pool = mgd_alloc_pool();
	tmp = php_midgard_template(pool, (*arg)->value.str.val);

	if( tmp== NULL ) {
		RETVAL_STRING("",1);
	} else {
		RETVAL_STRING(tmp,1);
	}

	mgd_free_pool(pool);
}

char * php_midgard_variable(midgard_pool * pool, char * name, char * member, char * type)
{
	zval **var;

	if (mgd_handle() == NULL) {
		php_error(E_ERROR, "Not a midgard request.");
		return NULL;
	}

	if (zend_hash_find (EG(active_symbol_table), name, 
			 strlen(name)+1, (void **) &var) == FAILURE) {
		MGD_LOG_START("Uninitialized variable $%s")
			MGD_LOG_ARG(name)
		MGD_LOG_END()
		php_error(E_NOTICE, "Uninitialized variable $%s", name);
		return NULL;
	}

	if (member) {

		if (!(Z_TYPE_PP(var) == IS_ARRAY || Z_TYPE_PP(var) == IS_OBJECT)) {
			MGD_LOG_START("Not an object or array: $%s")
				MGD_LOG_ARG(name)
			MGD_LOG_END()
			php_error(E_NOTICE, "Not an object or array: $%s", name);
			return NULL;
		}

		if (!(Z_TYPE_PP(var) == IS_OBJECT)) {
			if(zend_hash_find((*var)->value.ht, member, strlen(member)+1,
						(void **)&var)!= SUCCESS) {
				MGD_LOG_START("Uninitialized hash property $%s")
					MGD_LOG_ARG(member)
				MGD_LOG_END()
				php_error(E_NOTICE, "Uninitialized hash property $%s", member);
				return NULL;
			}
		} else {
			if(!MGD_PROPFIND((*var), member, var)) {
				MGD_LOG_START("Uninitialized member variable $%s")
					MGD_LOG_ARG(member)
				MGD_LOG_END()
				php_error(E_NOTICE, "Uninitialized member variable $%s",
									member);
				return NULL;
			}
		}
	}

	if(type && type[0] == 'x') {/* User Defined Filter func. (UDF/Xtension) */
		php_mgd_call_udf_function(type + 1, NULL, *var);
		return NULL;
	}

	convert_to_string_ex(var);
	return php_midgard_include(pool, name, (*var)->value.str.val, type);
}

MGD_FUNCTION(ret_type, variable, (type param))
{
	zval **var, **arg, **rec;
	char *tmp;
	midgard_pool *pool=NULL;

	if (ZEND_NUM_ARGS() == 1) {
		if( zend_get_parameters_ex(1,&var) == FAILURE ) {
			WRONG_PARAM_COUNT;
		} else {
			pool = mgd_alloc_pool();
			convert_to_string_ex(var);
			tmp = php_midgard_variable(pool, (*var)->value.str.val, NULL, NULL);
			if( tmp== NULL ) {
				RETVAL_STRING("",1);
			} else {
				RETVAL_STRING(tmp,1);
			}
		}
	}

	if (ZEND_NUM_ARGS() == 2) {
		if( zend_get_parameters_ex(2,&var,&arg) == FAILURE ) {
			WRONG_PARAM_COUNT;
		} else {
			pool = mgd_alloc_pool();
			convert_to_string_ex(var);
			convert_to_string_ex(arg);
			tmp = php_midgard_variable(pool, (*var)->value.str.val, NULL,
											 (*arg)->value.str.val);
			if( tmp== NULL ) {
				RETVAL_STRING("",1);
			} else {
				RETVAL_STRING(tmp,1);
			}
		}
	}

	if (ZEND_NUM_ARGS() == 3) {
		if( zend_get_parameters_ex(3,&var,&rec,&arg) == FAILURE ) {
			WRONG_PARAM_COUNT;
		} else {
			pool = mgd_alloc_pool();
			convert_to_string_ex(var);
			convert_to_string_ex(arg);
			convert_to_string_ex(rec);
			if( (*arg)->value.str.val[0] == '\0' ) {
				tmp = php_midgard_variable(pool, (*var)->value.str.val,
												 (*rec)->value.str.val,
												 NULL);
			} else {
				tmp = php_midgard_variable(pool, (*var)->value.str.val,
												 (*rec)->value.str.val,
												 (*arg)->value.str.val);
			}
			if( tmp== NULL ) {
				RETVAL_STRING("",1);
			} else {
				RETVAL_STRING(tmp,1);
			}
		}
	}
	mgd_free_pool(pool);
}

MGD_FUNCTION(ret_type, snippet, (type param))
{
	zval **file;
	char *part, *name;
	midgard_res *res;
	midgard_pool *pool;
	int upval, idval;
	midgard *mgd = mgd_handle(); // DG: GLOBAL(midgard_module_env).mgd;
	midgard_request_config *rcfg = mgd_rcfg();
	char *db = NULL;
	
	if (ZEND_NUM_ARGS() == 1) {
		if( zend_get_parameters_ex(1,&file) == FAILURE ) {
			WRONG_PARAM_COUNT;
		} else {
			convert_to_string_ex(file);
		}
	} else WRONG_PARAM_COUNT;

	/* EEH: if the page database has been defined you will want to include snippets from there too. */
	if (rcfg->database.page && rcfg->database.page->handle
			&& rcfg->database.page->handle->mgd) {
		mgd_select_database(php_rqst, rcfg->database.page, rcfg);
		db = rcfg->database.page->name; 
		MGD_LOG_START("Midgard: fetching snippet '%s' from database %s")
			MGD_LOG_ARG((*file)->value.str.val)
			MGD_LOG_ARG(db)
		MGD_LOG_END()
	}
	
	if (MGD_PARSE_COMMON_PATH(mgd, (*file)->value.str.val,
					"snippetdir", "snippet", &idval, &upval))
		RETURN_STRING("",1);
	

	res = mgd_sitegroup_record(mgd, "code", "snippet", idval);
	if (!res || !mgd_fetch(res)) {
		if (res)
			mgd_release(res);
		MGD_LOG_START("Midgard: snippet get record failed: %s")
			MGD_LOG_ARG((*file)->value.str.val)
		MGD_LOG_END()
		RETURN_STRING("",1);
	}

	pool = mgd_alloc_pool();
	if (!pool) {
		if (res)
			mgd_release(res);
		MGD_LOG_START("Midgard: snippet no pool: %s")
			MGD_LOG_ARG((*file)->value.str.val)
		MGD_LOG_END()
		RETURN_STRING("",1);
	}

	part = mgd_strdup(pool, mgd_colvalue(res, 0));
	name = mgd_strcat(pool, 2, "snippet://", (*file)->value.str.val);
	mgd_release(res);
	
	if (db) {
		MGD_LOG_START("Midgard: fetched snippet '%s' from database %s")
			MGD_LOG_ARG(name)
			MGD_LOG_ARG(db)
		MGD_LOG_END()
		mgd_select_database(php_rqst, rcfg->database.main, rcfg);
	}

	RETVAL_STRING(part,1);
	mgd_free_pool(pool);
}

/* DG {HACK ALERT}: Since the function zend_eval_string does not behave like
 * the statement eval(), thie following function is the exact copy of the
 * function zend_eval_string with some lines commented out.
 * This is necessary to keep the compatibility between eval() and mgd_eval()
 */
static int mgd_eval_string(char *str, zval *retval_ptr, char *string_name CLS_DC ELS_DC)
{
	zval pv;
	zend_op_array *new_op_array;
	zend_op_array *original_active_op_array = EG(active_op_array);
	zend_function_state *original_function_state_ptr = EG(function_state_ptr);
	int original_handle_op_arrays;
	int retval;

//	if (retval_ptr) {
//		pv.value.str.len = strlen(str)+sizeof("return  ;")-1;
//		pv.value.str.val = emalloc(pv.value.str.len+1);
//		strcpy(pv.value.str.val, "return ");
//		strcat(pv.value.str.val, str);
//		strcat(pv.value.str.val, " ;");
//	} else {
		pv.value.str.len = strlen(str);
		pv.value.str.val = estrndup(str, pv.value.str.len);
//	}
	pv.type = IS_STRING;

	/*printf("Evaluating '%s'\n", pv.value.str.val);*/

	original_handle_op_arrays = CG(handle_op_arrays);
	CG(handle_op_arrays) = 0;
	new_op_array = compile_string(&pv, string_name CLS_CC);
	CG(handle_op_arrays) = original_handle_op_arrays;

	if (new_op_array) {
		zval *local_retval_ptr=NULL;
		zval **original_return_value_ptr_ptr = EG(return_value_ptr_ptr);
		zend_op **original_opline_ptr = EG(opline_ptr);
		
		EG(return_value_ptr_ptr) = &local_retval_ptr;
		EG(active_op_array) = new_op_array;
		EG(no_extensions)=1;

		zend_execute(new_op_array ELS_CC);

		if (local_retval_ptr) {
			if (retval_ptr) {
				COPY_PZVAL_TO_ZVAL(*retval_ptr, local_retval_ptr);
			} else {
				zval_ptr_dtor(&local_retval_ptr);
			}
		} else {
			if (retval_ptr) {
				INIT_ZVAL(*retval_ptr);
			}
		}

		EG(no_extensions)=0;
		EG(opline_ptr) = original_opline_ptr;
		EG(active_op_array) = original_active_op_array;
		EG(function_state_ptr) = original_function_state_ptr;
		destroy_op_array(new_op_array);
		efree(new_op_array);
		EG(return_value_ptr_ptr) = original_return_value_ptr_ptr;
		retval = SUCCESS;
	} else {
		retval = FAILURE;
	}
	zval_dtor(&pv);
	return retval;
}

MGD_FUNCTION(ret_type, eval, (type param))
{
 	zval **string, **name;
	char *tmp, *value;
	midgard_pool *pool;

	RETVAL_FALSE;
	switch (ZEND_NUM_ARGS()) {
		case 2:
			if (zend_get_parameters_ex(2, &string, &name) == SUCCESS) {
				convert_to_string_ex(string);
				convert_to_string_ex(name);
				tmp = (*name)->value.str.val;
				break;
			}
		case 1:
			if (zend_get_parameters_ex(1, &string) == SUCCESS) {
				convert_to_string_ex(string);
				tmp = "mgd_eval()";
				break;
			}
		default:
			WRONG_PARAM_COUNT;
	}
	if((*string)->value.str.len) {
		pool = mgd_alloc_pool();
		value = php_eval_midgard(pool, tmp, (*string)->value.str.val, 0);
		if(mgd_eval_string(value, return_value, tmp CLS_CC ELS_CC) != SUCCESS) {
/* DG: we probably want to turn that off when stable and ready to release
 * or at least offer the user an option to turn it off, as it exposes the
 * PHP source (security issue here)
 */
			zend_syntax_highlighter_ini syntax_highlighter_ini;
			php_get_highlight_struct(&syntax_highlighter_ini);
			highlight_string(*string, &syntax_highlighter_ini, tmp);
			mgd_free_pool(pool);
			zend_bailout(); //exit(0);
		}
		mgd_free_pool(pool);
	}
}

MGD_FUNCTION(ret_type, register_filter, (type param))
{
 	zval **name, **function;
	zval *func, **retval;
	zval *udf;

	RETVAL_FALSE;
	udf = mgd_getudf();
	switch (ZEND_NUM_ARGS()) {
		case 2:
			if (zend_get_parameters_ex(2, &name, &function) == SUCCESS) {
				convert_to_string_ex(name);
				convert_to_string_ex(function);
				break;
			}
		case 1:
			if (zend_get_parameters_ex(1, &name) == SUCCESS) {
				convert_to_string_ex(name);
				function = NULL;
				break;
			}
		case 0:
			*return_value = *udf; zval_copy_ctor(return_value);
			return;
		default:
			WRONG_PARAM_COUNT;
	}
	if(function) {
		if((*function)->value.str.len) {	/* registration */
			MAKE_STD_ZVAL(func);
			*func = **function; zval_copy_ctor(func);
			if(zend_hash_update(udf->value.ht, (*name)->value.str.val,
								(*name)->value.str.len+1,
								&func,
								sizeof(func), NULL) == SUCCESS) {
				RETVAL_TRUE;
			}
		} else {		/* unregistration */
			if(zend_hash_del(udf->value.ht, (*name)->value.str.val,
								(*name)->value.str.len+1) == SUCCESS) {
				RETVAL_TRUE;
			}
		}
	} else {
		if(zend_hash_find(udf->value.ht, (*name)->value.str.val,
								(*name)->value.str.len+1,
								(void **)&retval) == SUCCESS) {
			*return_value = **retval; zval_copy_ctor(return_value);
		}
	}
}

#endif /* HAVE_MIDGARD */
