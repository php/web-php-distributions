/* $Id: preferences.c,v 1.7 2001/03/10 22:43:10 emile Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mgd_internal.h"
#include "mgd_oop.h"

MGD_FUNCTION(ret_type, list_preferences, (type param))
{
	zval **uid, **dom;
	int user;
	char *domain;

	RETVAL_FALSE;
	CHECK_MGD;
    switch (ZEND_NUM_ARGS()) {
	case 0:
		user = mgd_user(mgd_handle());
		domain = NULL;
		break;
	case 1:
		if (zend_get_parameters_ex(1, &uid) != SUCCESS)
			WRONG_PARAM_COUNT;
		convert_to_long_ex(uid);
		user = (*uid)->value.lval;
		domain = NULL;
		break;
	case 2:
		if (zend_get_parameters_ex(2, &uid, &dom) != SUCCESS)
			WRONG_PARAM_COUNT;
		convert_to_long_ex(uid);
		convert_to_string_ex(dom);
		user = (*uid)->value.lval;
		domain = (*dom)->value.str.val;
		break;
	default:
		WRONG_PARAM_COUNT;
	}

	if (user != mgd_user(mgd_handle()) && !mgd_isadmin(mgd_handle()))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
	
	if (domain)
		php_midgard_select(&MidgardPreferences, return_value, "id,uid,domain,name,value" SITEGROUP_SELECT,
						   "preference", "uid=$d AND domain=$q", "name",
						   user, domain);
	else
		php_midgard_select(&MidgardPreferences, return_value, "id,uid,domain,name,value" SITEGROUP_SELECT,
						   "preference", "uid=$d", "domain,name", user);
}

MGD_FUNCTION(ret_type, get_preference, (type param))
{
	zval **pid, **dom, **name;
	int id;

	RETVAL_FALSE;
	CHECK_MGD;
    switch (ZEND_NUM_ARGS()) {
	case 0:
		php_midgard_bless(return_value, &MidgardPreferences);
		mgd_object_init(return_value, "uid", "domain", "name", "value", NULL);
		return;
	case 1:
		if (zend_get_parameters_ex(1, &pid) != SUCCESS)
			WRONG_PARAM_COUNT;
		convert_to_long_ex(pid);
		id = (*pid)->value.lval;
		break;
	case 2:
		if (zend_get_parameters_ex(2, &dom, &name) != SUCCESS)
			WRONG_PARAM_COUNT;
		convert_to_string_ex(dom);
		convert_to_string_ex(name);
		id = mgd_exists_id(mgd_handle(), "preference",
						"uid=$d AND domain=$q AND name=$q",
						mgd_user(mgd_handle()),
						(*dom)->value.str.val, (*name)->value.str.val);
		break;
	case 3:
		if (zend_get_parameters_ex(3, &pid, &dom, &name) != SUCCESS)
			WRONG_PARAM_COUNT;
		convert_to_long_ex(pid);
		id = (*pid)->value.lval;
		convert_to_string_ex(dom);
		convert_to_string_ex(name);
		id = mgd_exists_id(mgd_handle(), "preference",
						"uid=$d AND domain=$q AND name=$q",
						id,
						(*dom)->value.str.val, (*name)->value.str.val);
		break;
	default:
		WRONG_PARAM_COUNT;
	}

	if (!id) RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
	if (!mgd_isadmin(mgd_handle()) &&
		mgd_user(mgd_handle()) != mgd_idfield(mgd_handle(), "uid", "preference", id))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

   php_midgard_get_object(return_value, MIDGARD_OBJECT_PREFERENCE, id);
}

MGD_FUNCTION(ret_type, create_preference, (type param))
{
	zval **uid, **domain, **name, **value, *self;
	
	RETVAL_FALSE;
	CHECK_MGD;
   if ((self = getThis()) != NULL) {
      if (ZEND_NUM_ARGS() != 0) { WRONG_PARAM_COUNT; }

      if (!MGD_PROPFIND(self, "uid", uid)
            || !MGD_PROPFIND(self, "domain", domain)
            || !MGD_PROPFIND(self, "name", name)
            || !MGD_PROPFIND(self, "value", value)
            ) {
         RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
      }
   } else {
	if (ZEND_NUM_ARGS() != 4
	    || zend_get_parameters_ex(4, &uid, &domain, &name, &value) != SUCCESS)
		WRONG_PARAM_COUNT;
   }
	convert_to_long_ex(uid);
	convert_to_string_ex(domain);
	convert_to_string_ex(name);
	convert_to_string_ex(value);
	
	if (mgd_user(mgd_handle()) != (*uid)->value.lval
         && !mgd_isadmin(mgd_handle()))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	if (!mgd_exists_id(mgd_handle(), "person", "id=$d", (*uid)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	php_midgard_create(return_value, "preference", "uid,domain,name,value",
					   "$d,$q,$q,$q", (*uid)->value.lval, (*domain)->value.str.val,
					   (*name)->value.str.val, (*value)->value.str.val);

	PHP_CREATE_REPLIGARD("preference",return_value->value.lval);
}

MGD_FUNCTION(ret_type, update_preference, (type param))
{
	zval **id, **value, *self;
	
	RETVAL_FALSE;
	CHECK_MGD;

   if ((self = getThis()) != NULL) {
      if (ZEND_NUM_ARGS() != 0) { WRONG_PARAM_COUNT; }

      if (!MGD_PROPFIND(self, "id", id)
            || !MGD_PROPFIND(self, "value", value)
            ) {
         RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
      }
   } else {
	if (ZEND_NUM_ARGS() != 2 || zend_get_parameters_ex(2, &id, &value) != SUCCESS)
		WRONG_PARAM_COUNT;
   }

	convert_to_long_ex(id);
	convert_to_string_ex(value);
	
	if (!mgd_isadmin(mgd_handle()) && mgd_user(mgd_handle()) !=
	    mgd_idfield(mgd_handle(), "uid", "preference", (*id)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
	
	php_midgard_update(return_value, "preference", "value=$q",
					   (*id)->value.lval, (*value)->value.str.val);
	PHP_UPDATE_REPLIGARD("preference", (*id)->value.lval);
}

MGD_FUNCTION(ret_type, delete_preference, (type param))
{
	IDINIT;
	RETVAL_FALSE;
	CHECK_MGD;
    if(mgd_has_dependants(mgd_handle(),id,"preference"))
	RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);

	if (!mgd_isadmin(mgd_handle()) &&
		mgd_user(mgd_handle()) != mgd_idfield(mgd_handle(), "uid", "preference", id))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
	
	php_midgard_delete(return_value, "preference", id);
	PHP_DELETE_REPLIGARD("preference", id);	
}

MidgardProperty MidgardPreferencesProperties [] = {
	{ IS_LONG,		"uid"		},
	{ IS_STRING,	"domain"	},
	{ IS_STRING,	"name"		},
	{ IS_STRING,	"value"		},
	{ 0,			NULL		}
};

MIDGARD_CLASS(MidgardPreferences, preference)
