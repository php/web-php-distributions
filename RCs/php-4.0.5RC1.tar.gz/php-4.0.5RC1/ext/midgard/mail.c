/* $Id: mail.c,v 1.5 2001/02/28 01:00:31 davidg Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <Zend/zend_API.h>
#include <midgard/midgard.h>
#include <mgd_internal.h>
#include <php_ini.h>

static void q_encode(FILE * out, const char *in, const char *encoding)
{
	unsigned char ch;
	int i, n = 0, encode = 0;

	for (i = 0; (ch=in[i]); i++) 
		if (ch > 127 || ch < 32)
			encode = 1;
	if (!encode) {
		fprintf(out, "%s", in);
		return;
	}

	fprintf(out, "=?%s?Q?", encoding);
	for (; (ch = *in); in++) {
		switch (ch) {
			case ' ':
				putc('_', out);
				n += 1;
				break;
			case '=':
			case '?':
			case '_':
				fprintf(out, "=%.2X", ch);
				n += 3;
				break;
			default:
				if (ch > 127 || ch < 32) {
					fprintf(out, "=%2X", ch);
					n += 3;
				}
				else {
					putc(ch, out);
					n += 1;
				}
				break;
		}
	}
	fprintf(out, "?=");
}

static void qp_encode(FILE * out, const char *in)
{
	unsigned char ch, ws = '\0';
	int n = 0;

	for (; (ch = *in); in++) {
		switch (ch) {
			case ' ':
			case '\t':
				if (ws) {
					putc(ws, out);
					n += 1;
				}
				ws = ch;
				break;
			case '\r':
			case '\n':
				if (ws) {
					fprintf(out, "=%.2X", ws);
					ws = '\0';
				}
				putc(ch, out);
				n = 0;
				break;
			default:
				if (ws) {
					putc(ws, out);
					n += 1;
					ws = '\0';
				}
				if (ch > 127 || ch < 32 || ch == '=') {
					fprintf(out, "=%2X", ch);
					n += 3;
				}
				else {
					putc(ch, out);
					n += 1;
				}
				break;
		}
		if (n > 71) {
			if (ws) {
				putc(ws, out);
				ws = '\0';
			}
			fprintf(out, "=\n");
			n = 0;
		}
	}
}

MGD_FUNCTION(ret_type, create_mail, (type param))
{
	zval **from, **to, **subject, **message;
	FILE *sendmail;
	midgard_pool *pool;
	char *header;
   char *sendmail_path = INI_STR("sendmail_path");

	RETVAL_FALSE;
	CHECK_MGD;

	if (ZEND_NUM_ARGS() != 4
	    || zend_get_parameters_ex(4, &from, &to, &subject, &message) != SUCCESS)
       {
		WRONG_PARAM_COUNT;
      }
	convert_to_string_ex(from);
	convert_to_string_ex(to);
	convert_to_string_ex(subject);
	convert_to_string_ex(message);

	if (!sendmail_path)
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	sendmail = popen(sendmail_path, "w");
	if (sendmail) {
		pool = mgd_alloc_pool();
		header = mgd_format(mgd_handle(), pool,
				    "From: $s\nTo: $s\n", (*from)->value.str.val,
				    (*to)->value.str.val);
		fprintf(sendmail, header);
		fprintf(sendmail, "Subject: ");
		q_encode(sendmail, (*subject)->value.str.val,
			 mgd_get_encoding(mgd_handle()));
		header =
		   mgd_format(mgd_handle(), pool,
			      "\nX-Mailer: Midgard $s\nMIME-Version: 1.0\n"
			      "Content-Type: text/plain; charset=$s\n",
			      mgd_version(mgd_handle()),
			      mgd_get_encoding(mgd_handle()));
		fprintf(sendmail, header);
		mgd_free_pool(pool);
		if (mgd_mail_need_qp(mgd_handle())) {
			fprintf(sendmail,
				"Content-Transfer-Encoding: quoted-printable\n\n");
			qp_encode(sendmail, (*message)->value.str.val);
		}
		else {
			fprintf(sendmail, "\n%s", (*message)->value.str.val);
		}
		putc('\n', sendmail);
		if (pclose(sendmail) != -1)
			RETVAL_TRUE;
	}
	else
		zend_error(E_WARNING,
			   "Could not execute mail delivery program");
}

