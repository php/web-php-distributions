/* $Id: file.c,v 1.7 2001/03/10 22:43:10 emile Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mgd_internal.h"
#include "mgd_oop.h"

MGD_FUNCTION(ret_type, list_files, (type param))
{
	IDINIT;
	CHECK_MGD;
	php_midgard_select(&MidgardFile, return_value, "id,article,type,name,content,size,md5" SITEGROUP_SELECT, "file", "article=$d", "name", id);
}

MGD_FUNCTION(ret_type, get_file, (type param))
{
	zval **id;
	CHECK_MGD;

	switch (ZEND_NUM_ARGS()) {
	case 0:
	php_midgard_bless(return_value, &MidgardFile);
	mgd_object_init(return_value, "article", "type", "name", "content", "size", "md5", NULL);
		return;
	case 1:
		if (zend_get_parameters_ex(1, &id) == SUCCESS) {
			convert_to_long_ex(id);
			break;
		} /* else fall through */
	default:
		WRONG_PARAM_COUNT;
	}

   php_midgard_get_object(return_value, MIDGARD_OBJECT_FILE, (*id)->value.lval);
}

MGD_FUNCTION(ret_type, create_file, (type param))
{
	zval **article, **type, **name, **content, **size, **md5, *self;
	
	RETVAL_FALSE;
	CHECK_MGD;

   if ((self = getThis()) != NULL) {
      if (ZEND_NUM_ARGS() != 0) { WRONG_PARAM_COUNT; }

      if (!MGD_PROPFIND(self, "article", article)
            || !MGD_PROPFIND(self, "type", type)
            || !MGD_PROPFIND(self, "name", name)
            || !MGD_PROPFIND(self, "content", content)
            || !MGD_PROPFIND(self, "size", size)
            || !MGD_PROPFIND(self, "md5", md5)
            ) {
         RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
      }
   } else {
	   if (ZEND_NUM_ARGS() != 6
	    || zend_get_parameters_ex(6, &article, &type, &name,
			     &content, &size, &md5) != SUCCESS)
		WRONG_PARAM_COUNT;
   }

	convert_to_long_ex(article);
	convert_to_string_ex(type);
	convert_to_string_ex(name);
	convert_to_string_ex(content);
	convert_to_long_ex(size);
	convert_to_string_ex(md5);
	
	if (!isarticleowner((*article)->value.lval)) RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
	
	if (!mgd_exists_id(mgd_handle(), "article", "id=$d", (*article)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	php_midgard_create(return_value, "file",
		       "article,type,name,content,size,md5",
		       "$d,$q,$q,$q,$d,$q", (*article)->value.lval,
		       (*type)->value.str.val, (*name)->value.str.val,
		       (*content)->value.str.val, (*size)->value.lval,
		       (*md5)->value.str.val);

	PHP_CREATE_REPLIGARD("file", return_value->value.lval);
}

MGD_FUNCTION(ret_type, update_file, (type param))
{
	zval **id, **type, **name, **content, *self;
	
	RETVAL_FALSE;
	CHECK_MGD;

   if ((self = getThis()) != NULL) {
      if (ZEND_NUM_ARGS() != 0) { WRONG_PARAM_COUNT; }

      if (!MGD_PROPFIND(self, "id", id)
            || !MGD_PROPFIND(self, "type", type)
            || !MGD_PROPFIND(self, "name", name)
            || !MGD_PROPFIND(self, "content", content)
            ) {
         RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
      }
   } else {
	   if (ZEND_NUM_ARGS() != 4
	    || zend_get_parameters_ex(4,
						 &id, &type, &name, &content) != SUCCESS)
		WRONG_PARAM_COUNT;
   }

	convert_to_long_ex(id);
	convert_to_string_ex(type);
	convert_to_string_ex(name);
	convert_to_string_ex(content);
	
	if (!isarticleowner(mgd_idfield(mgd_handle(), "article", "file",
									(*id)->value.lval)))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
	
	php_midgard_update(return_value, "file", "type=$q,name=$q,content=$q",
		       (*id)->value.lval, (*type)->value.str.val,
		       (*name)->value.str.val, (*content)->value.str.val);
	PHP_UPDATE_REPLIGARD("file",(*id)->value.lval);
}

MGD_FUNCTION(ret_type, delete_file, (type param))
{
	IDINIT;
	CHECK_MGD;
    if(mgd_has_dependants(mgd_handle(),id,"file"))
	RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);

	if (!isarticleowner(mgd_idfield(mgd_handle(), "article", "file", id)))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
	php_midgard_delete(return_value, "file", id);
	PHP_DELETE_REPLIGARD("file", id);
}

MidgardProperty MidgardFileProperties [] = {
	{ IS_LONG,		"article"	},
	{ IS_STRING,	"name"		},
	{ IS_STRING,	"type"		},
	{ IS_STRING,	"content"	},
	{ IS_STRING,	"md5"		},
	{ IS_LONG,		"size"		},
	{ 0,			NULL		}
};

MIDGARD_CLASS(MidgardFile, file)
