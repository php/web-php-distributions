/* $Id: image.c,v 1.6 2001/03/10 22:43:10 emile Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mgd_internal.h"
#include "mgd_oop.h"

MGD_FUNCTION(ret_type, list_images, (type param))
{
    RETVAL_FALSE;
	CHECK_MGD;
    if (ZEND_NUM_ARGS() != 0)
        WRONG_PARAM_COUNT;
    php_midgard_select(&MidgardImage, return_value, "id,src,x,y,info&1 AS online" SITEGROUP_SELECT,
                    "image", NULL, NULL);
}

#if 0
MGD_FUNCTION(ret_type, html_image, (type param))
{
    php_midgard_res *res;
    zval **id, **extra, eextra;

    RETVAL_FALSE;
	CHECK_MGD;
    switch (ZEND_NUM_ARGS()) {
    case 2:
        if (zend_get_parameters_ex(2, &id, &extra) != SUCCESS)
            WRONG_PARAM_COUNT;
        convert_to_string_ex(extra);
        break;
    case 1:
        if (zend_get_parameters_ex(1, &id) != SUCCESS)
            WRONG_PARAM_COUNT;
        extra = &eextra;
        (*extra)->value.str.val = "";
        break;
    default:
        WRONG_PARAM_COUNT;
    }
    convert_to_long_ex(id);

    res = mgd_query(midgard.mgd,
                    "SELECT src,x,y,info&1 FROM image WHERE id=$d",
                    (*id)->value.lval);
    if (res) {
        if (mgd_fetch(res) && mgd_sql2int(res, 3) == 0) {
          PUTS("<img src=\"/img/");
          PUTS(mgd_sql2str(res, 0));
          PUTS("\" ");
          PUTS((*extra)->value.str.val);
          PUTS(" width=\"");
          PUTS(mgd_sql2str(res, 1));
          PUTS("\" height=\"");
          PUTS(mgd_sql2str(res, 2));
          PUTS("\">");
          PUTS("\" height=\"");
          RETVAL_TRUE;
        }
        mgd_release(res);
    }
}
#endif

MGD_FUNCTION(ret_type, get_image, (type param))
{
	zval **id;
	CHECK_MGD;

	switch (ZEND_NUM_ARGS()) {
	case 0:
	php_midgard_bless(return_value, &MidgardImage);
	mgd_object_init(return_value, "src", "x", "y", "offline", NULL);
		return;
	case 1:
		if (zend_get_parameters_ex(1, &id) == SUCCESS) {
			convert_to_long_ex(id);
			break;
		} /* else fall through */
	default:
		WRONG_PARAM_COUNT;
	}

   php_midgard_get_object(return_value, MIDGARD_OBJECT_IMAGE, (*id)->value.lval);
}


MGD_FUNCTION(ret_type, create_image, (type param))
{
	zval **src, **x, **y, **offline, *self;

	RETVAL_FALSE;
	CHECK_MGD;

	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 0) {
			WRONG_PARAM_COUNT;
		}

		if (!MGD_PROPFIND(self, "src", src)
		    || !MGD_PROPFIND(self, "x", x)
		    || !MGD_PROPFIND(self, "y", y)
		    || !MGD_PROPFIND(self, "offline", offline)
		   ) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if (ZEND_NUM_ARGS() != 4
		    || zend_get_parameters_ex(4, &src, &x, &y, &offline) != SUCCESS)
			WRONG_PARAM_COUNT;
	}

	convert_to_string_ex(src);
	convert_to_long_ex(x);
	convert_to_long_ex(y);
	convert_to_long_ex(offline);

	php_midgard_create(return_value, "image", "src,x,y,info", "$q,$d,$d,$d",
			   (*src)->value.str.val, (*x)->value.lval, (*y)->value.lval,
			   (*offline)->value.lval == 1);

	PHP_CREATE_REPLIGARD("image", return_value->value.lval);
}

MGD_FUNCTION(ret_type, update_image, (type param))
{
	zval **id, **src, **x, **y, **offline, *self;

	RETVAL_FALSE;
	CHECK_MGD;
	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 0) {
			WRONG_PARAM_COUNT;
		}

		if (!MGD_PROPFIND(self, "id", id)
		    || !MGD_PROPFIND(self, "src", src)
		    || !MGD_PROPFIND(self, "x", x)
		    || !MGD_PROPFIND(self, "y", y)
		    || !MGD_PROPFIND(self, "offline", offline)
		   ) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if (ZEND_NUM_ARGS() != 5
		    || zend_get_parameters_ex(5, &id, &src, &x, &y,
				     &offline) != SUCCESS) WRONG_PARAM_COUNT;
	}

	convert_to_long_ex(id);
	convert_to_string_ex(src);
	convert_to_long_ex(x);
	convert_to_long_ex(y);
	convert_to_long_ex(offline);

	php_midgard_update(return_value, "image", "src=$q,x=$d,y=$d,info=$d",
			   (*id)->value.lval,
			   (*src)->value.str.val, (*x)->value.lval, (*y)->value.lval,
			   (*offline)->value.lval == 1);
	PHP_UPDATE_REPLIGARD("image", (*id)->value.lval);
}

MGD_FUNCTION(ret_type, delete_image, (type param))
{
    IDINIT;
	CHECK_MGD;
    if(mgd_has_dependants(mgd_handle(),id,"image"))
	RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);

    php_midgard_delete(return_value, "image", id);
    PHP_DELETE_REPLIGARD("image", id);
}

MidgardProperty MidgardImageProperties [] = {
	{ IS_STRING,	"src"		},
	{ IS_LONG,		"x"			},
	{ IS_LONG,		"y"			},
	{ IS_LONG,		"online"	},
	{ 0,			NULL		}
};
MIDGARD_CLASS(MidgardImage, image)
