/* $Id: mgd_internal.h,v 1.10 2001/03/10 22:43:10 emile Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "php.h"
#include "php_ini.h"
#include "SAPI.h"
#include "php_midgard.h"
#include "Zend/zend.h"
#include "Zend/zend_API.h"
#include "mgd_errno.h"
#include "mgd_access.h"

const char *article_sort(const char *order);

#define php_rqst    ((request_rec *) SG(server_context))
#define MGD_LOG_START(fmt)	ap_log_rerror(APLOG_MARK, APLOG_DEBUG | APLOG_NOERRNO, php_rqst, (fmt)
#define MGD_LOG_ARG(arg)	, (arg)
#define MGD_LOG_END()		);

#define RETURN_FALSE_BECAUSE(reason) { mgd_set_errno(reason); RETURN_FALSE; }
#define RETVAL_FALSE_BECAUSE(reason) { mgd_set_errno(reason); RETVAL_FALSE; }

#define CHECK_MGD \
   do { \
      if (!mgd_rcfg()) { \
         RETURN_FALSE_BECAUSE(MGD_ERR_NOT_CONNECTED); \
      } \
      mgd_reset_errno(); \
   } while (0);

#define MGD_FUNCTION(ret, name, param) \
   PHP_FUNCTION(mgd_##name)

#define MGD_FE(name, arg_types) \
   PHP_FE(mgd_##name, arg_types)

#define MGD_PROPFIND(object, prop, retval) \
   (zend_hash_find((object)->value.obj.properties, (prop), strlen(prop)+1, \
      (void**)&(retval)) == SUCCESS)
	
#define MGD_PROPFIND_CONST(object, prop, retval) \
   (zend_hash_find((object)->value.obj.properties, (prop), sizeof(prop), \
      (void**)&(retval)) == SUCCESS)

#define IDINIT \
   int id; zval *self, **id_zval; \
   if (!mgd_rcfg()) \
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_CONNECTED); \
   if ((self = getThis()) != NULL) { \
      if (! MGD_PROPFIND(self, "id", id_zval)) { \
         RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT); \
      } \
   } else { \
      if (ZEND_NUM_ARGS() != 1 \
            || zend_get_parameters_ex(1, &id_zval) != SUCCESS) \
      WRONG_PARAM_COUNT; \
   } \
   convert_to_long_ex(id_zval); \
   id = (*id_zval)->value.lval;

#define PHP_CREATE_REPLIGARD(table,id)\
   { \
      if(id != 0) CREATE_REPLIGARD(mgd_handle(), table, id) \
      else RETURN_FALSE_BECAUSE(MGD_ERR_ERROR); \
   }

#define PHP_DELETE_REPLIGARD(table,id) \
   { \
      if(id != 0) DELETE_REPLIGARD(mgd_handle(), table, id) \
      else RETURN_FALSE_BECAUSE(MGD_ERR_ERROR); \
   }

#define PHP_CREATE_REPLIGARD_VOID(table,id) \
   { \
      if(id != 0) CREATE_REPLIGARD(mgd_handle(), table, id)\
   }

#define PHP_UPDATE_REPLIGARD(table,id) \
   UPDATE_REPLIGARD(mgd_handle(), table, id)

#define MGD_MOVE_FUNCTION(table,roottable,name,rootname) \
MGD_FUNCTION(int, move_##name, (int id, int root)) \
{ \
   zval **id, **root; \
   RETVAL_FALSE; \
   CHECK_MGD; \
   if (ZEND_NUM_ARGS() != 2 \
         || zend_get_parameters_ex(2, &id, &root) != SUCCESS) \
      WRONG_PARAM_COUNT; \
   convert_to_long_ex(id); \
   convert_to_long_ex(root); \
   if(mgd_move_object(mgd_handle(), #table, #rootname, \
      (*id)->value.lval, (*root)->value.lval)) RETVAL_TRUE; \
   PHP_UPDATE_REPLIGARD(#table, (*id)->value.lval); \
   PHP_UPDATE_REPLIGARD(#roottable, (*root)->value.lval); \
}

int midgard_user_call_func(midgard *mgd, int id, int level, void * xparam);

#define MGD_WALK_FUNCTION(table) \
							MGD_WALK_FUNCTION_EX(table, table, up)
#define MGD_WALK_FUNCTION_EX(type, table, upfield) \
/* {{{ proto void walk_ ## type ## _tree(string func, id, level, xparam[[, order], sort]) \
*/ \
MGD_FUNCTION(void, walk_ ## type ## _tree,(string func, int id, int level, mixed &xparam[, order[, sort]])) \
{ \
   zval **id, **level, **xparam, *xp[2], **order; \
	zval **midgard_user_call_func_name, **sort = NULL; \
	CHECK_MGD; \
\
	switch (ZEND_NUM_ARGS()) { \
	case 6: \
      if (zend_get_parameters_ex(6, &midgard_user_call_func_name, &id, \
            &level, &xparam, &order, &sort) == FAILURE) { \
         WRONG_PARAM_COUNT; \
      } \
      break; \
	case 5: \
      if (zend_get_parameters_ex(5, &midgard_user_call_func_name, &id, \
            &level, &xparam, &order) == FAILURE) { \
         WRONG_PARAM_COUNT; \
      } else { \
         sort = NULL; \
      } \
      break; \
   case 4: \
      if (zend_get_parameters_ex(4, &midgard_user_call_func_name, &id, \
            &level, &xparam) == FAILURE) { \
         WRONG_PARAM_COUNT; \
      } else { \
         order = NULL; \
         sort = NULL; \
      } \
      break; \
   default: \
      WRONG_PARAM_COUNT; \
      break; \
   }\
\
	convert_to_string_ex(midgard_user_call_func_name); \
	convert_to_long_ex(level); \
	if (order) convert_to_long_ex(order); \
	convert_to_long_ex(id); \
	if(sort) convert_to_string_ex(sort); \
\
	xp[0] = (*xparam); \
	xp[1] = (*midgard_user_call_func_name); \
	RETVAL_LONG( \
		mgd_walk_table_tree(mgd_handle(), #table, #upfield, (*id)->value.lval, \
									   (*level)->value.lval, \
									   order ? (*order)->value.lval : 1, \
									   (void *)xp, \
									   midgard_user_call_func, \
									   sort ? (*sort)->value.str.val : NULL) \
	); \
} \
\
/* }}} */

/* Commonly used macros
*/

#define HOSTNAME_FIELD \
  "Concat('http', If(host.port=443, 's',''), '://', host.name, If(host.port=0 || host.port=443, '', Concat(':', host.port)),If(host.prefix='/', '/', Concat(host.prefix, '/'))) AS hostname"

#define PUBLIC_FIELD(n,name) "If(info&" #n "," #name ",'') AS " #name
#define PUBLIC_FIELDS \
  "info&2=2 AS addressp,info&4=4 as phonep,info&8=8 AS homepagep," \
  "info&16=16 AS emailp,info&32=32 AS extrap"

#define NAME_FIELD \
  "Concat(firstname,If(firstname=''||lastname='','',' '),lastname)"
#define RNAME_FIELD \
  "Concat(lastname,If(firstname=''||lastname='','',', '),firstname)"
#define NAME_FIELDS "firstname,lastname,username," \
  NAME_FIELD " AS name," RNAME_FIELD " AS rname"

#define ADDRESS_FIELD "Concat(street," \
  "If(street!=''&&(postcode!=''||city!=''),', ','')," \
  "postcode,If(postcode!=''&&city!='',' ',''),city)"
#define ADDRESS_FIELDS "street,postcode,city," ADDRESS_FIELD " AS address"

#define PHONE_FIELD "Concat(" \
  "handphone,If(handphone=''||(homephone=''&&workphone=''),'',', ')," \
  "homephone,If(homephone=''||workphone='','',', ')," \
  "workphone,If(workphone='','',' (ty�)'))"
#define PHONE_FIELDS "handphone,homephone,workphone," PHONE_FIELD " AS phone"

#define HOMEPAGE_FIELD "If(homepage='',''," \
  "Concat('<a href=\\\"',homepage,'\\\" title=\\\"',firstname,' ',lastname," \
  "'\\\">',homepage,'</a>'))"
#define HOMEPAGE_FIELDS "homepage," HOMEPAGE_FIELD " AS homepagelink"

#define EMAIL_FIELD "If(email='',''," \
  "Concat('<a href=\\\"mailto:',email,'\\\" title=\\\"',firstname,' '," \
  "lastname,'\\\">',email,'</a>'))"
#define EMAIL_FIELDS  "email," EMAIL_FIELD " AS emaillink"

#define GROUP_HOMEPAGE_FIELD "If(homepage='',''," \
  "Concat('<a href=\\\"',homepage,'\\\" title=\\\"',name," \
  "'\\\">',homepage,'</a>'))"
#define GROUP_HOMEPAGE_FIELDS "homepage," \
  GROUP_HOMEPAGE_FIELD " AS homepagelink"

#define GROUP_EMAIL_FIELD "If(email='',''," \
  "Concat('<a href=\\\"mailto:',email,'\\\" title=\\\"',name," \
  "'\\\">',email,'</a>'))"
#define GROUP_EMAIL_FIELDS  "email," GROUP_EMAIL_FIELD " AS emaillink"

#if HAVE_MIDGARD_SITEGROUPS
#define SITEGROUP_SELECT ",sitegroup"
#else
#define SITEGROUP_SELECT ""
#endif

/* Person macroses */
#define PERSON_SELECT \
  "id,username," NAME_FIELD " AS name," RNAME_FIELD " AS rname,extra," \
  "topic,department,office,info&1 AS admin,info>1 AS public" SITEGROUP_SELECT

/* Article macroses */
#define CALENDAR_FIELD \
  "If(IsNull(calstart),'',If(caldays=0,Date_Format(calstart,'%d.%m.%Y')," \
  "Concat(Date_Format(calstart," \
  "If(Year(calstart)!=Year(From_Days(To_Days(calstart)+caldays)),'%d.%m.%Y'," \
  "If(Month(calstart)!=Month(From_Days(To_Days(calstart)+caldays)),'%d.%m.','%d.')))," \
  "Date_Format(From_Days(To_Days(calstart)+caldays),'-%d.%m.%Y'))))"
#define ACALENDAR_FIELD \
  "If(IsNull(calstart),'',If(caldays=0,Date_Format(calstart,'%D %b. %Y')," \
  "Concat(Date_Format(calstart," \
  "If(Year(calstart)!=Year(From_Days(To_Days(calstart)+caldays)),'%D %b. %Y'," \
  "If(Month(calstart)!=Month(From_Days(To_Days(calstart)+caldays)),'%D %b.','%D')))," \
  "Date_Format(From_Days(To_Days(calstart)+caldays),'-%D %b. %Y'))))"
#define ALCALENDAR_FIELD \
  "If(IsNull(calstart),'',If(caldays=0,Date_Format(calstart,'%D %M %Y')," \
  "Concat(Date_Format(calstart," \
  "If(Year(calstart)!=Year(From_Days(To_Days(calstart)+caldays)),'%D %M %Y'," \
  "If(Month(calstart)!=Month(From_Days(To_Days(calstart)+caldays)),'%D %M','%D')))," \
  "Date_Format(From_Days(To_Days(calstart)+caldays),'-%D %M %Y'))))"
#define CALENDAR_FIELDS \
  CALENDAR_FIELD " AS calendar," \
  ACALENDAR_FIELD " AS acalendar," \
  ALCALENDAR_FIELD " AS alcalendar," \
  "Unix_Timestamp(calstart) AS startdate," \
  "Unix_Timestamp(Date_Add(calstart, INTERVAL caldays DAY)) AS enddate," \
  "caldays,Date_Format(calstart,'%d.%m.%Y') AS calstart," \
  "Date_Format(From_Days(To_Days(calstart)+caldays),'%d.%m.%Y') As calstop"

#define ARTICLE_CALENDAR CALENDAR_FIELDS

#if HAVE_MIDGARD_SITEGROUPS
#define ARTICLE_SITEGROUP_SELECT ",article.sitegroup"
#else
#define ARTICLE_SITEGROUP_SELECT ""
#endif

#define ARTICLE_SELECT \
  "article.id AS id,article.name AS name,title,abstract,content,author," \
  NAME_FIELD " AS authorname,article.topic AS topic," \
  "Date_format(article.created,'%d.%m.%Y') AS date," \
  "Date_format(article.created,'%D %b. %Y') AS adate," \
  "Date_format(article.created,'%D %M %Y') AS aldate," \
  "url,icon,extra1,extra2,extra3,article.score AS score,type," \
  "Unix_Timestamp(article.created) AS created,article.creator AS creator," \
  "Unix_Timestamp(revised) AS revised,revisor,revision," \
  "Unix_Timestamp(locked) AS locked,locker," \
  "Unix_Timestamp(approved) AS approved,approver" ARTICLE_SITEGROUP_SELECT

#define ARTICLE_SELECT_FAST \
  "id,name,title,abstract,content,author,topic," \
  "Date_format(article.created,'%d.%m.%Y') AS date," \
  "Date_format(article.created,'%D %b. %Y') AS adate," \
  "Date_format(article.created,'%D %M %Y') AS aldate," \
  "url,icon,extra1,extra2,extra3,article.score AS score,type," \
  "Unix_Timestamp(article.created) AS created,article.creator AS creator," \
  "Unix_Timestamp(revised) AS revised,revisor,revision," \
  "Unix_Timestamp(locked) AS locked,locker," \
  "Unix_Timestamp(approved) AS approved,approver" SITEGROUP_SELECT

#define ARTICLE_FROM "article,person"
#define ARTICLE_FROM_FAST "article"

/* Macroses for Events */
#if HAVE_MIDGARD_SITEGROUPS
#define EVENT_SITEGROUP     " AND sitegroup in (0,$d)"
#define EVENT_SITEGROUP2    " AND event.sitegroup in (0,$d)"\
							" AND eventmember.sitegroup in (0,$d)"
#else
#define EVENT_SITEGROUP     ""
#define EVENT_SITEGROUP2    ""
#endif
#define EVENT_COUNT_WHERE_0 "start>=Unix_Timestamp(Now())" EVENT_SITEGROUP
#define EVENT_COUNT_WHERE_1 "start>=Unix_Timestamp(Now())"\
							" AND end<=$d" EVENT_SITEGROUP
#define EVENT_COUNT_WHERE_2 "start>=$d AND end<=$d" EVENT_SITEGROUP
#define EVENT_COUNT_WHERE_3 "start>=$d AND end<=$d"\
							" AND event.id=eventmember.eid"\
							" AND eventmember.uid=$d" EVENT_SITEGROUP
#define EVENT_COUNT_WHERE_4 "start>=$d AND end<=$d"\
							" AND event.id=eventmember.eid"\
							" AND eventmember.uid=$d"\
							" AND event.type=$d" EVENT_SITEGROUP2
#define EVENT_COUNT_WHERE_43 "start>=$d AND end<=$d"\
							" AND event.type=$d" EVENT_SITEGROUP
#define EVENT_COUNT_TABLE 	"event"
#define EVENT_COUNT_TABLE_2 "event,eventmember"

#define EVENT_START 0
#define EVENT_END   1

#define EVENT_MONTH_WHERE 	   "((start<$d AND end>$d)"\
						  	   " OR (start>$d AND start<$d)"\
						  	   " OR (end>$d AND end<$d))" EVENT_SITEGROUP
#define EVENT_MONTH_WHERE_TYPE "((start<$d AND end>$d)"\
						       " OR (start>$d AND start<$d)"\
							   " OR (end>$d AND end<$d))"\
							   " AND type=$d" EVENT_SITEGROUP
/* Macroses for Event Members */
#define EVENT_PUBLIC_FIELD(n,name) \
		"If(person.id<>$d,If(info&" #n "," #name ",'')," #name ") AS " #name

#define EVENT_EMAIL_FIELD \
		"If(person.id<>$d,If(Info&16,If(email='',''," \
  "Concat('<a href=\\\"mailto:',email,'\\\" title=\\\"',firstname,' '," \
  "lastname,'\\\">',email,'</a>')),'')," \
  "Concat('<a href=\\\"mailto:',email,'\\\" title=\\\"',firstname,' '," \
  "lastname,'\\\">',email,'</a>')) AS emaillink"

/* DG: fixing an incompatibility with a certain state of PHP's CVS...
 * not needed anymore, but who knows...
#ifdef add_property_unset
#undef add_property_unset
#define add_property_unset(__arg, __key) add_property_unset_ex(__arg, __key, strlen(__key) + 1)
#endif
*/

#define MGD_INIT_CLASS_ENTRY(class_container, class_name, functions) \
	{ \
		class_container.name = strdup(class_name); \
		class_container.name_length = strlen(class_name); \
		class_container.builtin_functions = functions; \
		class_container.handle_function_call = NULL; \
		class_container.handle_property_get = NULL; \
		class_container.handle_property_set = NULL; \
	}

#define MGD_INIT_OVERLOADED_CLASS_ENTRY(class_container, class_name, functions, handle_fcall, handle_propget, handle_propset) \
	{															\
		class_container.name = strdup(class_name);				\
		class_container.name_length = strlen(class_name);		\
		class_container.builtin_functions = functions;			\
		class_container.handle_function_call = handle_fcall;	\
		class_container.handle_property_get = handle_propget;	\
		class_container.handle_property_set = handle_propset;	\
	}
