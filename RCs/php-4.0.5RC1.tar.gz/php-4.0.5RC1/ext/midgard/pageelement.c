/* $Id: pageelement.c,v 1.7 2001/03/10 22:43:10 emile Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mgd_internal.h"
#include "mgd_oop.h"

MGD_FUNCTION(ret_type, list_page_elements, (type param))
{
    IDINIT;
	CHECK_MGD;
    php_midgard_select(&MidgardPageElement, return_value, "id,name" SITEGROUP_SELECT, "pageelement", "page=$d", "name", id);
}

MGD_FUNCTION(ret_type, get_page_element, (type param))
{
	zval **id;
	CHECK_MGD;

	switch (ZEND_NUM_ARGS()) {
	case 0:
		php_midgard_bless(return_value, &MidgardPageElement);
		mgd_object_init(return_value, "page", "name", "value", "inherit", NULL);
		return;
	case 1:
		if (zend_get_parameters_ex(1, &id) == SUCCESS) {
			convert_to_long_ex(id);
			break;
		} /* else fall through */
	default:
		WRONG_PARAM_COUNT;
	}

   php_midgard_get_object(return_value, MIDGARD_OBJECT_PAGEELEMENT, (*id)->value.lval);
}

MGD_FUNCTION(ret_type, get_page_element_by_name, (type param))
{
    zval **page, **name;
	CHECK_MGD;
    if (ZEND_NUM_ARGS() != 2
	|| zend_get_parameters_ex(2, &page, &name) != SUCCESS)
	WRONG_PARAM_COUNT;
    convert_to_long_ex(page);
    convert_to_string_ex(name);
    php_midgard_get_by_name(&MidgardPageElement, return_value, "id,page,name,value,info&1 AS inherit",
	    "pageelement", "page", (*page)->value.lval, (*name)->value.str.val);
}

MGD_FUNCTION(ret_type, create_page_element, (type param))
{
   zval **page, **name, **value, **inherit, *self;

	RETVAL_FALSE;
	CHECK_MGD;

	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 0) {
			WRONG_PARAM_COUNT;
		}

		if (!MGD_PROPFIND(self, "page", page)
		    || !MGD_PROPFIND(self, "name", name)
		    || !MGD_PROPFIND(self, "value", value)
		    || !MGD_PROPFIND(self, "inherit", inherit)
		   ) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if (ZEND_NUM_ARGS() != 4
		    || zend_get_parameters_ex(4, &page, &name, &value,
				     &inherit) != SUCCESS) WRONG_PARAM_COUNT;
	}

	convert_to_long_ex(page);
	convert_to_string_ex(name);
	convert_to_string_ex(value);
	convert_to_long_ex(inherit);

	if (!(*page)->value.lval
            || !mgd_exists_id(mgd_handle(), "page", "id=$d", (*page)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	if (!ispageowner((*page)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	if (mgd_exists_id(mgd_handle(), "pageelement", "page=$d AND name=$q",
			  (*page)->value.lval, (*name)->value.str.val))
		RETURN_FALSE_BECAUSE(MGD_ERR_DUPLICATE);

	php_midgard_create(return_value, "pageelement", "page,name,value,info",
			   "$d,$q,$q,$d", (*page)->value.lval, (*name)->value.str.val,
			   (*value)->value.str.val, ((*inherit)->value.lval != 0));

	PHP_CREATE_REPLIGARD("pageelement", return_value->value.lval);
}

MGD_FUNCTION(ret_type, update_page_element, (type param))
{
	zval **id, **name, **value, **inherit, *self;

	RETVAL_FALSE;
	CHECK_MGD;

	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 0) {
			WRONG_PARAM_COUNT;
		}

		if (!MGD_PROPFIND(self, "id", id)
		    || !MGD_PROPFIND(self, "name", name)
		    || !MGD_PROPFIND(self, "value", value)
		    || !MGD_PROPFIND(self, "inherit", inherit)
		   ) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if (ZEND_NUM_ARGS() != 4
		    || zend_get_parameters_ex(4, &id, &name, &value,
				     &inherit) != SUCCESS) WRONG_PARAM_COUNT;
	}
	convert_to_long_ex(id);
	convert_to_string_ex(name);
	convert_to_string_ex(value);
	convert_to_long_ex(inherit);

	if (!ispageowner(mgd_idfield(mgd_handle(), "page", "pageelement",
				     (*id)->value.lval)))
		   RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	php_midgard_update(return_value, "pageelement",
			   "name=$q,value=$q,info=$d", (*id)->value.lval,
			   (*name)->value.str.val, (*value)->value.str.val,
			   ((*inherit)->value.lval != 0));
	PHP_UPDATE_REPLIGARD("pageelement", (*id)->value.lval);
}

MGD_FUNCTION(ret_type, delete_page_element, (type param))
{
    IDINIT;
	CHECK_MGD;
    if(mgd_has_dependants(mgd_handle(),id,"pageelement"))
	RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);

    if (!ispageowner(mgd_idfield(mgd_handle(), "page", "pageelement", id)))
      RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
    php_midgard_delete(return_value, "pageelement", id);
    PHP_DELETE_REPLIGARD("pageelement", id);
}

MGD_FUNCTION(ret_type, copy_page_element, (type param))
{
    zval **id, **newpage;
	RETVAL_FALSE;
	CHECK_MGD;
    switch (ZEND_NUM_ARGS()) {
	case 2:
	    if (zend_get_parameters_ex(2, &id, &newpage) != SUCCESS)
		WRONG_PARAM_COUNT;
	break;
	case 1:
	    if (zend_get_parameters_ex(1, &id) != SUCCESS)
		WRONG_PARAM_COUNT;
	    newpage = NULL;
	break;
	default:
		WRONG_PARAM_COUNT;
    }
    
    convert_to_long_ex(id);
    if(newpage) convert_to_long_ex(newpage);

#if HAVE_MIDGARD_SITEGROUPS
	/* newpage must be in same SG or be 0 */
	if (newpage && (*newpage)->value.lval != 0
		&& !mgd_exists_bool(mgd_handle(), "page src,page tgt",
										"src.id=$d AND tgt.id=$d"
										" AND (src.sitegroup=tgt.sitegroup"
											" OR src.sitegroup=0"
											" OR tgt.sitegroup=0)",
										(*id)->value.lval, (*newpage)->value.lval)) RETURN_FALSE_BECAUSE(MGD_ERR_SITEGROUP_VIOLATION);
#endif

    RETVAL_LONG(mgd_copy_page_element(mgd_handle(), (*id)->value.lval, 
	newpage ? (*newpage)->value.lval : 0));

}


MGD_MOVE_FUNCTION(pageelement,page,page_element,page)

MidgardProperty MidgardPageElementProperties [] = {
	{ IS_LONG,		"page"		},
	{ IS_STRING,	"name"		},
	{ IS_STRING,	"value"		},
	{ IS_LONG,		"inherit"	},
	{ 0,			NULL		}
};
MIDGARD_CLASS(MidgardPageElement, page_element)
