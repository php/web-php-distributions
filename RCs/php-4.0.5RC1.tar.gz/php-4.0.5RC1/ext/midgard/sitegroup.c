/* $Id: sitegroup.c,v 1.8 2001/03/11 14:36:42 davidg Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mgd_internal.h"
#include "mgd_oop.h"

MGD_FUNCTION(ret_type, has_sitegroups, (type param))
{
#if HAVE_MIDGARD_SITEGROUPS
	RETURN_TRUE;
#else
	RETURN_FALSE;
#endif
}

#if HAVE_MIDGARD_SITEGROUPS
MGD_FUNCTION(ret_type, list_sitegroups, (type param))
{
  php_midgard_select(&MidgardSitegroup, return_value, "*", "sitegroup", NULL, "name");
}

MGD_FUNCTION(ret_type, create_sitegroup, (type param))
{
	zval **zv_name, *self;

	RETVAL_FALSE;
	CHECK_MGD;

	if (!mgd_isroot(mgd_handle()))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 0) {
			WRONG_PARAM_COUNT;
		}

		if (!MGD_PROPFIND(self, "name", zv_name)
		   ) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if ((ZEND_NUM_ARGS() != 1)
		    || (zend_get_parameters_ex(1, &zv_name) !=
			SUCCESS)) WRONG_PARAM_COUNT;
	}

	convert_to_string_ex(zv_name);

	/* no 'magic' chars in sitegroup name */
	if (strpbrk((*zv_name)->value.str.val, MIDGARD_LOGIN_RESERVED_CHARS))
		RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_NAME);

	if (mgd_exists_bool
	    (mgd_handle(), "sitegroup", "name=$q",
	     (*zv_name)->value.str.val)) RETURN_FALSE_BECAUSE(MGD_ERR_DUPLICATE);

	php_midgard_create(return_value, "sitegroup",
			   "name,admingroup", "$q,$d", (*zv_name)->value.str.val,
			   0);

	PHP_CREATE_REPLIGARD("sitegroup", return_value->value.lval);
}

MGD_FUNCTION(ret_type, get_sitegroup, (type param))
{
	zval **id;
	CHECK_MGD;

	switch (ZEND_NUM_ARGS()) {
	case 0:
		php_midgard_bless(return_value, &MidgardSitegroup);
		mgd_object_init(return_value, "name", "admingroup", "realm", NULL);
		return;
	case 1:
		if (zend_get_parameters_ex(1, &id) == SUCCESS) {
			convert_to_long_ex(id);
			break;
		} /* else fall through */
	default:
		WRONG_PARAM_COUNT;
	}

   php_midgard_get_object(return_value, MIDGARD_OBJECT_SITEGROUP, (*id)->value.lval);
}

MGD_FUNCTION(ret_type, update_sitegroup, (type param))
{
	zval **zv_id, **zv_name, **zv_admingroup, **zv_realm, *self;
	int group;
	int id, admingroup;

	RETVAL_FALSE;
	CHECK_MGD;

	if (!mgd_isroot(mgd_handle()))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 0) {
			WRONG_PARAM_COUNT;
		}

		if (!MGD_PROPFIND(self, "id", zv_id)
		    || !MGD_PROPFIND(self, "name", zv_name)
		    || !MGD_PROPFIND(self, "admingroup", zv_admingroup)
		    || !MGD_PROPFIND(self, "realm", zv_realm)
		   ) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if ((ZEND_NUM_ARGS() != 4)
		    ||
		    (zend_get_parameters_ex
		     (4, &zv_id, &zv_name, &zv_admingroup,
		      &zv_realm) != SUCCESS)) WRONG_PARAM_COUNT;
	}

	convert_to_string_ex(zv_name);
	convert_to_string_ex(zv_realm);
	convert_to_long_ex(zv_admingroup);
	convert_to_long_ex(zv_id);

	id = (*zv_id)->value.lval;
	admingroup = (*zv_admingroup)->value.lval;

	if (id == 0)
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	group = mgd_exists_id(mgd_handle(), "sitegroup", "name=$q",
				(*zv_name)->value.str.val);
	if (group != 0 && group != id)
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	/* check admingroup == sitegroup || admingroup == 0 */
	if (admingroup != 0
	    && !mgd_exists_bool(mgd_handle(), "grp", "id=$d and sitegroup=$d",
				admingroup, id)
	   )
		RETURN_FALSE_BECAUSE(MGD_ERR_SITEGROUP_VIOLATION);

	php_midgard_update(return_value,
			   "sitegroup",
			   "name=$q, admingroup=$d, realm=$q",
			   id,
			   (*zv_name)->value.str.val,
			   admingroup, (*zv_realm)->value.str.val);
	PHP_UPDATE_REPLIGARD("sitegroup", id);
}

MGD_FUNCTION(ret_type, delete_sitegroup, (type param))
{
  IDINIT;
  CHECK_MGD;

  if (!mgd_isroot(mgd_handle())) RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

  if (mgd_global_exists(mgd_handle(), "sitegroup=$d", id)) RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);

  php_midgard_delete(return_value, "sitegroup", id);
  PHP_DELETE_REPLIGARD("sitegroup", id);
}

MGD_FUNCTION(ret_type, oop_sitegroup_get, (type param))
{
zval *self = NULL;
zval **pv_table, **pv_id;
int sitegroup;

   CHECK_MGD;

   if ((self=getThis()) == NULL) {
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }

   if (zend_hash_find(self->value.obj.properties, "__table__", 10,
         (void **) &pv_table) != SUCCESS) {
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }
   if (zend_hash_find(self->value.obj.properties, "id", 3,
         (void **) &pv_id) != SUCCESS) {
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }
   convert_to_string_ex(pv_table);
   convert_to_long_ex(pv_id);

   if (strcmp((*pv_table)->value.str.val, "sitegroup") == 0) {
      RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
   }

   if (ZEND_NUM_ARGS() != 0) { WRONG_PARAM_COUNT; }

   sitegroup = mgd_idfield(mgd_handle(), "sitegroup",
      (*pv_table)->value.str.val,(*pv_id)->value.lval);

   php_midgard_sitegroup_get(&MidgardSitegroup, return_value,
      0, "*", "sitegroup", sitegroup);
}

MGD_FUNCTION(ret_type, oop_sitegroup_set, (type param))
{
   zval *self;
   zval **zv_sitegroup;
   zval **zv_table, **zv_id;

   CHECK_MGD;

	if (!mgd_isroot(mgd_handle())) {
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
   }

	if ((self = getThis()) == NULL) {
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }

   if (ZEND_NUM_ARGS() != 1) { WRONG_PARAM_COUNT; }

   if (zend_hash_find(self->value.obj.properties, "__table__", 10,
         (void **) &zv_table) != SUCCESS) {
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }
   if (zend_hash_find(self->value.obj.properties, "id", 3,
         (void **) &zv_id) != SUCCESS) {
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_OBJECT);
   }

   convert_to_string_ex(zv_table);
   convert_to_long_ex(zv_id);

   if (strcmp((*zv_table)->value.str.val, "sitegroup") == 0) {
      RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
   }

   if (zend_get_parameters_ex(1, &zv_sitegroup) == FAILURE) {
      WRONG_PARAM_COUNT;
   }

   convert_to_long_ex(zv_sitegroup);

   if ((*zv_sitegroup)->value.lval != 0
         && !mgd_exists_bool(mgd_handle(), "sitegroup", "id=$d",
               (*zv_sitegroup)->value.lval)) {
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
   }

   php_midgard_update(return_value,
      (*zv_table)->value.str.val,
      "sitegroup=$d", (*zv_id)->value.lval,
      (*zv_sitegroup)->value.lval);
   mgd_update_repligard(mgd_handle(), (*zv_table)->value.str.val, (*zv_id)->value.lval,
      "sitegroup=$d", (*zv_sitegroup)->value.lval);
}

MidgardProperty MidgardSitegroupProperties [] = {
	{ IS_STRING,	"name"			},
	{ IS_LONG,		"admingroup"	},
	{ IS_STRING,	"realm"			},
	{ 0,			NULL			}
};

MIDGARD_HANDLERS_DECL(sitegroup)
static zend_function_entry MidgardSitegroupMethods[] = {
//      MidgardSitegroup class constructor
//      PHP_FALIAS(midgardsitegroup,   mgd_ctor_sitegroup,  NULL)
   PHP_FALIAS(create,	mgd_create_sitegroup,	NULL)
   PHP_FALIAS(update,	mgd_update_sitegroup,	NULL)
   PHP_FALIAS(delete,	mgd_delete_sitegroup,	NULL)
   PHP_FALIAS(fetch,	mgd_oop_list_fetch,		NULL)
   PHP_FALIAS(guid,		mgd_oop_guid_get,		NULL)
   MIDGARD_OOP_PARAMETER_METHODS
   MIDGARD_OOP_ATTACHMENT_METHODS
   {  NULL,             NULL,                         NULL}
};
MidgardClass MidgardSitegroup = {
   "MidgardSitegroup",
   "sitegroup",
   MidgardSitegroupMethods,
   {},
   mgd_sitegroup_call_function_handler,
   mgd_sitegroup_get_property_handler,
   mgd_sitegroup_set_property_handler,
   MidgardSitegroupProperties,
   NULL
};
MIDGARD_HANDLERS(MidgardSitegroup, sitegroup)

#endif
