/* $Id: topic.c,v 1.12 2001/03/10 22:43:10 emile Exp $
Copyright (C) 1999 Jukka Zitting <jukka.zitting@iki.fi>
Copyright (C) 2000 The Midgard Project ry
Copyright (C) 2000 Emile Heyns, Aurora SA <emile@iris-advies.com>

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU Lesser General Public License as published
by the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "mgd_internal.h"
#include "mgd_oop.h"

MGD_FUNCTION(ret_type, is_topic_owner, (type param))
{
	IDINIT;
	CHECK_MGD;
	RETVAL_LONG(istopicowner(id));
}

static const char *topic_sort(const char *order)
{
	static struct
	{
		const char *order, *sort;
	}
	sort[] =
	{
		{
		"alpha", "name ASC"}
		, {
		"reverse alpha", "name DESC"}
		, {
		"score", "score ASC,name ASC"}
		, {
		"reverse score", "score DESC,name ASC"}
		, {
		"revised", "revised ASC"}
		, {
		"reverse revised", "revised DESC"}
		, {
		"created", "created ASC"}
		, {
		"reverse created", "created DESC"}
		, {
		NULL, "score DESC,name"}
	};
	int i;

	for (i = 0; sort[i].order; i++)
		if (strcmp(order, sort[i].order) == 0)
			return sort[i].sort;

	return sort[i].sort;
}

MGD_FUNCTION(ret_type, list_topics, (type param))
{
	const char *sortv = NULL;
	zval **id, **sortn;

	RETVAL_FALSE;
	CHECK_MGD;
	switch (ZEND_NUM_ARGS()) {
		case 2:
			if (zend_get_parameters_ex(2, &id, &sortn) == SUCCESS) {
				convert_to_long_ex(id);
				convert_to_string_ex(sortn);
				sortv = topic_sort((*sortn)->value.str.val);
				break;
			}
		case 1:
			if (zend_get_parameters_ex(1, &id) == SUCCESS) {
				convert_to_long_ex(id);
				sortv = "score DESC,name";
				break;
			}
		default:
			wrong_param_count();
	}

#if 0
	if (!istopicreader(id))
		return;
#endif

	php_midgard_select(&MidgardTopic, return_value,
			   "id,score,name,owner,extra,description,code,created,"
            "revised,creator,revisor" SITEGROUP_SELECT,
			   "topic", "up=$d", sortv, (*id)->value.lval);
}

MGD_FUNCTION(ret_type, is_in_topic_tree, (type param))
{
	zval **root, **topic;
	int i;

	RETVAL_FALSE;
	CHECK_MGD;
	if (ZEND_NUM_ARGS() != 2
	    || zend_get_parameters_ex(2, &root, &topic) != SUCCESS)
		   WRONG_PARAM_COUNT;
	convert_to_long_ex(root);
	convert_to_long_ex(topic);

	if((*topic)->value.lval == 0 || /* useless to waste time if topic=0 */
				!mgd_exists_id(mgd_handle(),
						"topic", "id=$d",
						(*topic)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
	if ((*root)->value.lval == 0)
		RETURN_TRUE; /* always true if root=0 */
	if(!mgd_exists_id(mgd_handle(), "topic", "id=$d", (*root)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);
#if 0
	if (!istopicreader((*topic)->value.lval))
		return;
#endif

	if((i = mgd_is_in_tree(mgd_handle(), "topic", "up",
				(*root)->value.lval, (*topic)->value.lval)))
		RETURN_TRUE;
}

MGD_FUNCTION(ret_type, get_topic, (type param))
{
	zval **id, **name;

	CHECK_MGD;

	switch (ZEND_NUM_ARGS()) {
		case 0:
			php_midgard_bless(return_value, &MidgardTopic);
			mgd_object_init(return_value, "id", "up", "name",
					 "extra", "owner", "score",
					 "description", "revised", "created",
					 "revisor", "creator", "revision",
					 "code", NULL);
			return;
		case 1:
			if (zend_get_parameters_ex(1, &id) == SUCCESS) {
				convert_to_long_ex(id);
            php_midgard_get_object(return_value, MIDGARD_OBJECT_TOPIC,
               (*id)->value.lval);
			}
			else {
				WRONG_PARAM_COUNT;
			}
			break;
		case 2:
			if (zend_get_parameters_ex(2, &id, &name) == SUCCESS) {
				convert_to_long_ex(id);
				convert_to_string_ex(name);
				php_midgard_get_by_name
				   (&MidgardTopic, return_value,
				    "id,up,score,name,description,extra,owner,code,"
				    "creator,Unix_timestamp(created) as created,"
				    "revisor,Unix_timestamp(revised) as revised,"
				    "revision", "topic", "up",
				    (*id)->value.lval, (*name)->value.str.val);
			}
			else {
				WRONG_PARAM_COUNT;
			}
			break;
		default:
			WRONG_PARAM_COUNT;
	}
}

MGD_FUNCTION(ret_type, get_topic_by_name, (type param))
{
   /* EEH: just an alias */
   php_if_mgd_get_topic(INTERNAL_FUNCTION_PARAM_PASSTHRU);
}

MGD_FUNCTION(ret_type, create_topic, (type param))
{
	zval **up, **name, **description, **extra, **owner, **code;
	zval *self;

	CHECK_MGD;
	RETVAL_FALSE;

	if ((self = getThis()) != NULL) {
		if (!MGD_PROPFIND(self, "up", up)
		    || !MGD_PROPFIND(self, "name", name)
		    || !MGD_PROPFIND(self, "description", description)
		    || !MGD_PROPFIND(self, "extra", extra)
		    || !MGD_PROPFIND(self, "owner", owner)
		    || !MGD_PROPFIND(self, "code", code)) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if (ZEND_NUM_ARGS() != 6
		    || zend_get_parameters_ex(6, &up, &name, &description,
					      &extra, &owner, &code) != SUCCESS)
			WRONG_PARAM_COUNT;
	}

	convert_to_long_ex(up);
	convert_to_string_ex(name);
	convert_to_string_ex(description);
	convert_to_string_ex(extra);
	convert_to_long_ex(owner);
	convert_to_string_ex(code);

	if (!istopicowner((*up)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

   if (mgd_exists_id(mgd_handle(), "topic", "up=$d AND name=$q",
			     (*up)->value.lval, (*name)->value.str.val))
		RETURN_FALSE_BECAUSE(MGD_ERR_DUPLICATE);

	if ((*up)->value.lval != 0
         && !mgd_exists_id(mgd_handle(), "topic", "id=$d", (*up)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	/* TODO: should we in fact allow owner == 0 for non-root? */
	if ((*owner)->value.lval != 0
         && !mgd_exists_id(mgd_handle(), "grp", "id=$d", (*owner)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	php_midgard_create(return_value, "topic",
			   "up,name,description,extra,owner,code,"
			   "creator,created,revisor,revised,revision",
			   "$d,$q,$q,$q,$d,$q,$d,Now(),$d,Now(),0",
			   (*up)->value.lval, (*name)->value.str.val,
			   (*description)->value.str.val,
			   (*extra)->value.str.val, (*owner)->value.lval,
			   (*code)->value.str.val, mgd_user(mgd_handle()),
			   mgd_user(mgd_handle()));
	PHP_CREATE_REPLIGARD("topic", return_value->value.lval);
}

MGD_FUNCTION(ret_type, update_topic, (type param))
{
	zval **id, **name, **description, **extra, **owner, **code, *self;

	RETVAL_FALSE;
	CHECK_MGD;

	if ((self = getThis()) != NULL) {
		if (!MGD_PROPFIND(self, "id", id)
			|| !MGD_PROPFIND(self, "name", name)
		    || !MGD_PROPFIND(self, "description", description)
		    || !MGD_PROPFIND(self, "extra", extra)
		    || !MGD_PROPFIND(self, "owner", owner)
		    || !MGD_PROPFIND(self, "code", code)) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if (ZEND_NUM_ARGS() != 6
		    || zend_get_parameters_ex(6, &id, &name, &description,
					      &extra, &owner, &code) != SUCCESS) {
			WRONG_PARAM_COUNT;
		}
	}

	convert_to_long_ex(id);
	convert_to_string_ex(name);
	convert_to_string_ex(description);
	convert_to_string_ex(extra);
	convert_to_string_ex(code);
	convert_to_long_ex(owner);

	if (!istopicowner((*id)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	/* TODO: should we in fact allow owner == 0 for non-root? */
	if ((*owner)->value.lval != 0
         && !mgd_exists_id(mgd_handle(), "grp", "id=$d", (*owner)->value.lval))
      RETURN_FALSE_BECAUSE(MGD_ERR_NOT_EXISTS);

	php_midgard_update(return_value, "topic",
			   "name=$q,description=$q,extra=$q,owner=$d,code=$q,"
			   "revisor=$d,revised=Now(),revision=revision+1",
			   (*id)->value.lval, (*name)->value.str.val,
			   (*description)->value.str.val,
			   (*extra)->value.str.val, (*owner)->value.lval,
			   (*code)->value.str.val, mgd_user(mgd_handle()));
	PHP_UPDATE_REPLIGARD("topic", (*id)->value.lval);
}

MGD_FUNCTION(ret_type, update_topic_score, (type param))
{
	zval **id, **score, *self;

	RETVAL_FALSE;
	CHECK_MGD;

	if ((self = getThis()) != NULL) {
		if (ZEND_NUM_ARGS() != 1 || zend_get_parameters_ex(1, &score) !=
		    SUCCESS) {
			WRONG_PARAM_COUNT;
		}
		if (!MGD_PROPFIND(self, "id", id)) {
			RETURN_FALSE_BECAUSE(MGD_ERR_INVALID_OBJECT);
		}
	}
	else {
		if (ZEND_NUM_ARGS() != 2
		    || zend_get_parameters_ex(2, &id, &score) != SUCCESS)
			WRONG_PARAM_COUNT;
	}

	convert_to_long_ex(id);
	convert_to_long_ex(score);

	if (!istopicowner((*id)->value.lval))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);

	php_midgard_update(return_value, "topic", "score=$d", (*id)->value.lval,
			   (*score)->value.lval);
	PHP_UPDATE_REPLIGARD("topic", (*id)->value.lval);
}

MGD_FUNCTION(ret_type, delete_topic, (type param))
{
	IDINIT;
	CHECK_MGD;
	if (mgd_has_dependants(mgd_handle(), id, "topic"))
		RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);
	if (mgd_exists_id(mgd_handle(), "article", "topic=$d", id))
		RETURN_FALSE_BECAUSE(MGD_ERR_HAS_DEPENDANTS);

	if (!istopicowner(mgd_idfield(mgd_handle(), "up", "topic", id)))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
	php_midgard_delete(return_value, "topic", id);
	PHP_DELETE_REPLIGARD("topic", id);
}

MGD_FUNCTION(ret_type, copy_topic, (type param))
{
	zval **id, **root;
	int id_r;
	int new_root;

	RETVAL_FALSE;
	CHECK_MGD;
        switch (ZEND_NUM_ARGS()) {
		case 2:
			if (zend_get_parameters_ex(2, &id, &root) !=
			    SUCCESS) WRONG_PARAM_COUNT;
			convert_to_long_ex(root);
	                new_root = (*root)->value.lval;    
			break;
		case 1:
			if (zend_get_parameters_ex(1, &id) != SUCCESS)
				WRONG_PARAM_COUNT;
	      convert_to_long_ex(id);
			new_root =   mgd_idfield(mgd_handle(), "up", "topic",(*id)->value.lval);
			break;
		default:
			WRONG_PARAM_COUNT;
	}
	convert_to_long_ex(id);

	/* if new_root is 0 or if not owner, access denied (unless isadmin) */
	if (!istopicowner(new_root)) {
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
   }

#if HAVE_MIDGARD_SITEGROUPS
	/* root must be in same SG or be 0 */
	if (new_root != 0 && 
			!mgd_exists_bool(mgd_handle(), "topic src, topic tgt",
			   "src.id=$d AND tgt.id=$d"
			   " AND (src.sitegroup=tgt.sitegroup"
			   " OR src.sitegroup=0" " OR tgt.sitegroup=0)",
			   (*id)->value.lval, new_root))
		RETURN_FALSE_BECAUSE(MGD_ERR_SITEGROUP_VIOLATION);
#endif

	id_r = mgd_copy_topic(mgd_handle(), (*id)->value.lval);
	if (id_r) {
		php_midgard_update(return_value, "topic", "up=$i", id_r,
				   new_root);
		PHP_UPDATE_REPLIGARD("topic", id_r);
	}
	RETVAL_LONG(new_root);
}

MGD_FUNCTION(ret_type, delete_topic_tree, (type param))
{
	IDINIT;
	CHECK_MGD;
	if (!istopicowner(mgd_idfield(mgd_handle(), "up", "topic", id)))
		RETURN_FALSE_BECAUSE(MGD_ERR_ACCESS_DENIED);
	if (mgd_delete_topic(mgd_handle(), id))
		RETVAL_TRUE;
}

MGD_MOVE_FUNCTION(topic, topic, topic, up)

MGD_WALK_FUNCTION(topic)

MidgardProperty MidgardTopicProperties [] = {
	{ IS_LONG,		"up"			},
	{ IS_STRING,	"name"			},
	{ IS_STRING,	"extra"			},
	{ IS_STRING,	"description"	},
	{ IS_STRING,	"code"			},
	{ IS_LONG,		"owner"			},
	{ IS_LONG,		"score"			},
	{ IS_LONG,		"revised"		},
	{ IS_LONG,		"created"		},
	{ IS_LONG,		"revisor"		},
	{ IS_LONG,		"creator"		},
	{ IS_LONG,		"revision"		},
	{ 0,			NULL			}
};

MIDGARD_HANDLERS_DECL(topic)
static zend_function_entry MidgardTopicMethods[] = {
   PHP_FALIAS(midgardtopic,   mgd_ctor_topic,       NULL)
   PHP_FALIAS(create,   mgd_create_topic,       NULL)
   PHP_FALIAS(update,   mgd_update_topic,       NULL)
   PHP_FALIAS(delete,   mgd_delete_topic,       NULL)
   PHP_FALIAS(setscore, mgd_update_topic_score, NULL)
   PHP_FALIAS(fetch,    mgd_oop_list_fetch,     NULL)
   MIDGARD_OOP_ATTACHMENT_METHODS
   MIDGARD_OOP_SITEGROUP_METHODS
   MIDGARD_OOP_PARAMETER_METHODS
   {  NULL,             NULL,                   NULL}
};
MidgardClass MidgardTopic = {
   "MidgardTopic",
   "topic",
   MidgardTopicMethods,
   {},
   mgd_topic_call_function_handler,
   mgd_topic_get_property_handler,
   mgd_topic_set_property_handler,
   MidgardTopicProperties,
   NULL
};
MIDGARD_HANDLERS(MidgardTopic, topic)
