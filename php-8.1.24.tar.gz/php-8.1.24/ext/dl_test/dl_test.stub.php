<?php

/** @generate-class-entries */

function dl_test_test1(): void {}

function dl_test_test2(string $str = ""): string {}
