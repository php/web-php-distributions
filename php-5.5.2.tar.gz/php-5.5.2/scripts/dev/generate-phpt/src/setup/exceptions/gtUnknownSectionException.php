<?php

class gtUnknownSectionException extends RuntimeException
  {
  }
?>