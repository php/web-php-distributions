#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	TC_STRING	257
#define	TC_ENCAPSULATED_STRING	258
#define	BRACK	259
#define	SECTION	260
#define	CFG_TRUE	261
#define	CFG_FALSE	262

