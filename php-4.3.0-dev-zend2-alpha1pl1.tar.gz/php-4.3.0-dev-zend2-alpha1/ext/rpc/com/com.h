#ifndef COM_H
#define COM_H

#include "../handler.h"
#include "../php_rpc.h"

ZEND_FUNCTION(com_addref);

#endif