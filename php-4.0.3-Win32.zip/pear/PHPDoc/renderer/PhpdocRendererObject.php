<?php
class PhpdocRendererObject extends PhpdocObject {
	
	var $warn;
	
	var $accessor;
		
} // end class PhpdocRendererObject
?>