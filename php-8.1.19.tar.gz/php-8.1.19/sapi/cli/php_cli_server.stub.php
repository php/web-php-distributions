<?php

function apache_request_headers(): array {}

function apache_response_headers(): array {}

function getallheaders(): array {}
