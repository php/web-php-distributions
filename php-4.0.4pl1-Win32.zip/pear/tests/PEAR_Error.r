new PEAR_Error object(pear_error)(8) {
  ["classname"]=>
  string(10) "pear_error"
  ["error_message_prefix"]=>
  string(0) ""
  ["error_prepend"]=>
  string(0) ""
  ["error_append"]=>
  string(0) ""
  ["mode"]=>
  int(0)
  ["level"]=>
  int(1024)
  ["message"]=>
  string(13) "unknown error"
  ["code"]=>
  int(0)
}
isError 1 bool(true)
isError 2 bool(false)
