<?

  phpinfo();

?>
