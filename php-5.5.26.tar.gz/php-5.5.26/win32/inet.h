#include <php.h>
#include <Winsock2.h>

PHPAPI int inet_aton(const char *cp, struct in_addr *inp);
